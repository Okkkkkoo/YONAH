PORT=3000 NODE_ENV=development npx tsx server/index.ts
