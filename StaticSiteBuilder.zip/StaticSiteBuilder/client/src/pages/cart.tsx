import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { MainLayout } from '@/components/layouts/main-layout';
import { Button } from '@/components/ui/button';
import { Trash2, Plus, Minus, ArrowRight, ShoppingBag } from 'lucide-react';
import { useCart } from '@/hooks/use-cart';
import { DEFAULT_PRODUCT_IMAGE } from '@/lib/constants';

export default function Cart() {
  const { 
    items, 
    totalItems, 
    subtotal, 
    shipping, 
    total, 
    updateItemQuantity, 
    removeItem, 
    isLoading 
  } = useCart();

  // Local state to track quantity changes
  const [quantities, setQuantities] = useState<Record<number, number>>({});

  // Initialize quantities from cart items
  useEffect(() => {
    const newQuantities: Record<number, number> = {};
    items.forEach(item => {
      newQuantities[item.id] = item.quantity;
    });
    setQuantities(newQuantities);
  }, [items]);

  const handleQuantityChange = (id: number, value: string) => {
    const numValue = parseInt(value);
    if (!isNaN(numValue) && numValue > 0) {
      setQuantities(prev => ({
        ...prev,
        [id]: numValue
      }));
    }
  };

  const handleQuantityBlur = (id: number) => {
    if (quantities[id]) {
      updateItemQuantity(id, quantities[id]);
    }
  };

  const handleIncrement = (id: number) => {
    const newQuantity = (quantities[id] || 0) + 1;
    setQuantities(prev => ({
      ...prev,
      [id]: newQuantity
    }));
    updateItemQuantity(id, newQuantity);
  };

  const handleDecrement = (id: number) => {
    const currentQuantity = quantities[id] || 0;
    if (currentQuantity > 1) {
      const newQuantity = currentQuantity - 1;
      setQuantities(prev => ({
        ...prev,
        [id]: newQuantity
      }));
      updateItemQuantity(id, newQuantity);
    }
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 max-w-7xl py-10">
        <h1 className="text-2xl font-bold text-slate-900 mb-8">Shopping Cart</h1>
        
        {items.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-10 text-center">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="h-8 w-8 text-slate-400" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Your cart is empty</h2>
            <p className="text-slate-600 mb-6">Looks like you haven't added any products to your cart yet.</p>
            <Button asChild>
              <Link href="/products">Start Shopping</Link>
            </Button>
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="md:col-span-2">
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-200">
                  <div className="flex justify-between items-center">
                    <h2 className="text-lg font-semibold text-slate-900">Cart Items ({totalItems})</h2>
                    <span className="text-sm text-slate-500">Price</span>
                  </div>
                </div>
                
                {/* Cart Items List */}
                <div className="divide-y divide-slate-200">
                  {items.map(item => (
                    <div key={item.id} className="p-6 flex flex-col sm:flex-row items-start sm:items-center">
                      {/* Product Image */}
                      <div className="w-24 h-24 bg-slate-100 rounded overflow-hidden mr-4 flex-shrink-0 mb-4 sm:mb-0">
                        <img 
                          src={item.product.imageUrl || DEFAULT_PRODUCT_IMAGE} 
                          alt={item.product.name} 
                          className="w-full h-full object-contain"
                        />
                      </div>
                      
                      {/* Product Info */}
                      <div className="flex-1 min-w-0">
                        <Link href={`/products/${item.productId}`}>
                          <a className="text-slate-900 font-medium hover:text-primary">
                            {item.product.name}
                          </a>
                        </Link>
                        <div className="text-sm text-slate-500 mt-1">{item.product.category.name}</div>
                        
                        {/* Mobile Price - shown only on small screens */}
                        <div className="sm:hidden text-primary font-semibold mt-2">
                          ${(Number(item.product.price) * item.quantity).toFixed(2)}
                        </div>
                        
                        {/* Quantity Control */}
                        <div className="flex items-center mt-4">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-l-md rounded-r-none"
                            onClick={() => handleDecrement(item.id)}
                            disabled={isLoading || (quantities[item.id] || item.quantity) <= 1}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <input
                            type="number"
                            min="1"
                            value={quantities[item.id] || item.quantity}
                            onChange={(e) => handleQuantityChange(item.id, e.target.value)}
                            onBlur={() => handleQuantityBlur(item.id)}
                            className="w-12 h-8 border-y border-slate-200 text-center focus:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                          />
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-r-md rounded-l-none"
                            onClick={() => handleIncrement(item.id)}
                            disabled={isLoading}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            className="ml-4 text-slate-500 hover:text-red-500"
                            onClick={() => removeItem(item.id)}
                            disabled={isLoading}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            <span className="sr-only sm:not-sr-only text-xs">Remove</span>
                          </Button>
                        </div>
                      </div>
                      
                      {/* Price - hidden on small screens */}
                      <div className="hidden sm:block text-primary font-semibold ml-4">
                        ${(Number(item.product.price) * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
                
                {/* Continue Shopping */}
                <div className="p-6 border-t border-slate-200">
                  <Button variant="link" asChild className="px-0">
                    <Link href="/products">
                      <span>← Continue Shopping</span>
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Order Summary */}
            <div className="md:col-span-1">
              <div className="bg-white rounded-lg shadow-sm p-6 sticky top-20">
                <h2 className="text-lg font-semibold text-slate-900 mb-4">Order Summary</h2>
                
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Subtotal ({totalItems} items)</span>
                    <span className="font-medium">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Shipping</span>
                    <span className="font-medium">
                      {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                    </span>
                  </div>
                  {shipping === 0 && (
                    <div className="text-xs text-green-600">
                      You've qualified for free shipping!
                    </div>
                  )}
                  <div className="pt-3 border-t border-slate-200">
                    <div className="flex justify-between font-semibold">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
                
                <Button asChild className="w-full mt-6">
                  <Link href="/checkout">
                    <span className="flex items-center justify-center">
                      Proceed to Checkout
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </span>
                  </Link>
                </Button>
                
                <div className="mt-6 text-sm text-slate-500">
                  <p className="mb-2">We accept:</p>
                  <div className="flex space-x-2">
                    <div className="w-10 h-6 bg-slate-200 rounded"></div>
                    <div className="w-10 h-6 bg-slate-200 rounded"></div>
                    <div className="w-10 h-6 bg-slate-200 rounded"></div>
                    <div className="w-10 h-6 bg-slate-200 rounded"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
