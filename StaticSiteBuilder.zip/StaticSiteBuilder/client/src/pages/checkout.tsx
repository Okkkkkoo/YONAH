import { useState } from 'react';
import { useLocation, Link } from 'wouter';
import { MainLayout } from '@/components/layouts/main-layout';
import { 
  Card, 
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle 
} from '@/components/ui/card';
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/use-cart';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  CreditCard, 
  LockIcon, 
  CheckCircle, 
  ChevronsRight, 
  User, 
  MapPin, 
  Truck, 
  ShoppingBag 
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { CHECKOUT_STEPS } from '@/lib/constants';
import { DEFAULT_PRODUCT_IMAGE } from '@/lib/constants';

// Form validation schema
const checkoutSchema = z.object({
  // Shipping information
  firstName: z.string().min(2, 'First name is required'),
  lastName: z.string().min(2, 'Last name is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().min(10, 'Phone number is required'),
  address: z.string().min(5, 'Address is required'),
  city: z.string().min(2, 'City is required'),
  state: z.string().min(2, 'State is required'),
  postalCode: z.string().min(5, 'Postal code is required'),
  country: z.string().min(2, 'Country is required'),
  
  // Payment information
  paymentMethod: z.enum(['creditCard', 'paypal']),
  cardName: z.string().optional(),
  cardNumber: z.string().optional(),
  cardExpiry: z.string().optional(),
  cardCvc: z.string().optional(),
  
  // Additional
  notes: z.string().optional(),
});

type CheckoutFormValues = z.infer<typeof checkoutSchema>;

export default function Checkout() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const { items, subtotal, shipping, total, clearCart } = useCart();
  
  // State for tracking checkout step
  const [activeStep, setActiveStep] = useState<string>('shipping');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderId, setOrderId] = useState<number | null>(null);
  
  // Initialize form
  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      postalCode: '',
      country: '',
      paymentMethod: 'creditCard',
      notes: '',
    },
  });
  
  // If there are no items in the cart, redirect to cart page
  if (items.length === 0 && !orderComplete) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 max-w-7xl py-10">
          <div className="bg-white rounded-lg shadow-sm p-10 text-center">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="h-8 w-8 text-slate-400" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Your cart is empty</h2>
            <p className="text-slate-600 mb-6">You need to add items to your cart before checking out.</p>
            <Button asChild>
              <Link href="/products">Start Shopping</Link>
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }
  
  // Handle form submission
  const onSubmit = async (data: CheckoutFormValues) => {
    try {
      setIsProcessing(true);
      
      if (activeStep === 'shipping') {
        // Move to payment step
        setActiveStep('payment');
        setIsProcessing(false);
        return;
      }
      
      if (activeStep === 'payment') {
        // Simulate payment processing
        // In a real app, you would integrate with a payment processor here
        
        // Create the order
        const orderData = {
          order: {
            userId: 1, // In a real app, this would be the current user's ID
            total: total,
            status: 'pending',
            address: data.address,
            city: data.city,
            state: data.state,
            postalCode: data.postalCode,
            country: data.country,
            phone: data.phone,
          },
          items: items.map(item => ({
            productId: item.productId,
            quantity: item.quantity,
            price: Number(item.product.price),
          })),
        };
        
        const response = await apiRequest('POST', '/api/orders', orderData);
        const orderResponse = await response.json();
        
        // Clear the cart
        await clearCart();
        
        // Show success step
        setOrderId(orderResponse.id);
        setOrderComplete(true);
        setActiveStep('confirmation');
        
        toast({
          title: "Order Placed Successfully",
          description: `Your order #${orderResponse.id} has been placed.`,
        });
      }
    } catch (error) {
      console.error('Checkout error:', error);
      toast({
        title: "Error",
        description: "There was a problem processing your order. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  // If order is complete, show confirmation
  if (orderComplete) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 max-w-7xl py-10">
          <div className="max-w-xl mx-auto">
            <Card>
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl">Order Confirmed!</CardTitle>
                <CardDescription>Thank you for your purchase</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-md">
                  <div className="text-sm text-slate-500 mb-1">Order Number</div>
                  <div className="font-medium">{orderId}</div>
                </div>
                
                <div>
                  <div className="text-sm font-medium mb-2">Order Details</div>
                  <div className="space-y-2">
                    {items.map(item => (
                      <div key={item.id} className="flex items-center">
                        <div className="w-10 h-10 bg-slate-100 rounded overflow-hidden mr-3">
                          <img 
                            src={item.product.imageUrl || DEFAULT_PRODUCT_IMAGE} 
                            alt={item.product.name} 
                            className="w-full h-full object-contain"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium truncate">{item.product.name}</div>
                          <div className="text-xs text-slate-500">Qty: {item.quantity}</div>
                        </div>
                        <div className="text-sm font-medium">${(Number(item.product.price) * item.quantity).toFixed(2)}</div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Shipping</span>
                    <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
                  </div>
                  <div className="flex justify-between font-medium pt-1">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>
                
                <div className="text-sm text-slate-500">
                  <p>We've sent a confirmation email to your email address with the order details.</p>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/">Return to Home</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 max-w-7xl py-10">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">Checkout</h1>
        
        {/* Checkout Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center">
            {CHECKOUT_STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div 
                  className={`flex items-center justify-center w-8 h-8 rounded-full ${
                    activeStep === step.id 
                      ? 'bg-primary text-white' 
                      : CHECKOUT_STEPS.findIndex(s => s.id === activeStep) > index
                        ? 'bg-green-500 text-white'
                        : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {CHECKOUT_STEPS.findIndex(s => s.id === activeStep) > index ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : (
                    index + 1
                  )}
                </div>
                <div 
                  className={`ml-2 text-sm font-medium ${
                    activeStep === step.id ? 'text-primary' : 'text-slate-600'
                  }`}
                >
                  {step.name}
                </div>
                {index < CHECKOUT_STEPS.length - 1 && (
                  <div className="w-16 mx-2">
                    <ChevronsRight className="h-4 w-4 text-slate-400" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {/* Checkout Form */}
          <div className="md:col-span-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Shipping Information */}
                {activeStep === 'shipping' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <MapPin className="mr-2 h-5 w-5 text-primary" />
                        Shipping Information
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="firstName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>First Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="lastName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Last Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="john.doe@example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone</FormLabel>
                              <FormControl>
                                <Input placeholder="(123) 456-7890" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Address</FormLabel>
                            <FormControl>
                              <Input placeholder="123 Main St" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="city"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>City</FormLabel>
                              <FormControl>
                                <Input placeholder="New York" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="state"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>State</FormLabel>
                              <FormControl>
                                <Input placeholder="NY" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="postalCode"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Postal Code</FormLabel>
                              <FormControl>
                                <Input placeholder="10001" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a country" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="USA">United States</SelectItem>
                                <SelectItem value="Canada">Canada</SelectItem>
                                <SelectItem value="UK">United Kingdom</SelectItem>
                                <SelectItem value="Australia">Australia</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="notes"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Order Notes (Optional)</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Special instructions for delivery" 
                                className="resize-none" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                    <CardFooter>
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={isProcessing}
                      >
                        {isProcessing ? 'Processing...' : 'Continue to Payment'}
                      </Button>
                    </CardFooter>
                  </Card>
                )}
                
                {/* Payment Information */}
                {activeStep === 'payment' && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <CreditCard className="mr-2 h-5 w-5 text-primary" />
                        Payment Method
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={form.control}
                        name="paymentMethod"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormControl>
                              <RadioGroup
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                className="flex flex-col space-y-1"
                              >
                                <div className="flex items-center space-x-2 border rounded-md p-3">
                                  <RadioGroupItem value="creditCard" id="creditCard" />
                                  <Label htmlFor="creditCard" className="flex items-center cursor-pointer">
                                    <CreditCard className="h-5 w-5 mr-2" />
                                    Credit/Debit Card
                                  </Label>
                                </div>
                                
                                <div className="flex items-center space-x-2 border rounded-md p-3">
                                  <RadioGroupItem value="paypal" id="paypal" />
                                  <Label htmlFor="paypal" className="flex items-center cursor-pointer">
                                    <div className="h-5 w-5 mr-2 flex items-center justify-center font-bold text-blue-600">P</div>
                                    PayPal
                                  </Label>
                                </div>
                              </RadioGroup>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      {form.watch('paymentMethod') === 'creditCard' && (
                        <div className="bg-slate-50 p-4 rounded-md space-y-4">
                          <FormField
                            control={form.control}
                            name="cardName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Name on Card</FormLabel>
                                <FormControl>
                                  <Input placeholder="John Doe" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="cardNumber"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Card Number</FormLabel>
                                <FormControl>
                                  <Input placeholder="**** **** **** ****" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="cardExpiry"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Expiry Date</FormLabel>
                                  <FormControl>
                                    <Input placeholder="MM/YY" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="cardCvc"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>CVC</FormLabel>
                                  <FormControl>
                                    <Input placeholder="123" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="flex items-center text-sm text-slate-500">
                            <LockIcon className="h-4 w-4 mr-2" />
                            Your payment info is secure and encrypted
                          </div>
                        </div>
                      )}
                      
                      {form.watch('paymentMethod') === 'paypal' && (
                        <div className="bg-slate-50 p-4 rounded-md text-center">
                          <p className="text-sm text-slate-600 mb-2">You will be redirected to PayPal to complete your payment.</p>
                          <div className="h-10 bg-blue-100 rounded flex items-center justify-center text-blue-600 font-bold">
                            PayPal Placeholder
                          </div>
                        </div>
                      )}
                    </CardContent>
                    <CardFooter className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                      <Button 
                        variant="outline" 
                        type="button" 
                        className="w-full" 
                        onClick={() => setActiveStep('shipping')}
                        disabled={isProcessing}
                      >
                        Back
                      </Button>
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={isProcessing}
                      >
                        {isProcessing ? 'Processing...' : 'Place Order'}
                      </Button>
                    </CardFooter>
                  </Card>
                )}
              </form>
            </Form>
          </div>
          
          {/* Order Summary */}
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="max-h-60 overflow-auto">
                    {items.map(item => (
                      <div key={item.id} className="flex items-center py-2 border-b border-slate-100 last:border-b-0">
                        <div className="w-12 h-12 bg-slate-100 rounded overflow-hidden mr-3 relative flex-shrink-0">
                          <img 
                            src={item.product.imageUrl || DEFAULT_PRODUCT_IMAGE} 
                            alt={item.product.name} 
                            className="w-full h-full object-contain"
                          />
                          <div className="absolute -top-1 -right-1 bg-slate-800 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                            {item.quantity}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium truncate">{item.product.name}</div>
                          <div className="text-xs text-slate-500">${Number(item.product.price).toFixed(2)} each</div>
                        </div>
                        <div className="text-sm font-medium ml-2">
                          ${(Number(item.product.price) * item.quantity).toFixed(2)}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Subtotal</span>
                      <span className="font-medium">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-600">Shipping</span>
                      <span className="font-medium">
                        {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                      </span>
                    </div>
                    <div className="pt-3 border-t border-slate-200 flex justify-between font-semibold">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>
                  
                  {shipping === 0 && (
                    <div className="text-xs text-green-600 flex items-center">
                      <Truck className="h-3 w-3 mr-1" />
                      Free shipping applied
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" asChild className="w-full">
                  <Link href="/cart">Edit Cart</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}

// Label component
const Label = ({ children, ...props }: React.LabelHTMLAttributes<HTMLLabelElement>) => {
  return (
    <label {...props} className="text-sm font-medium">
      {children}
    </label>
  );
};
