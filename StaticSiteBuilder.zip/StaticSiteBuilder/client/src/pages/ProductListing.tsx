import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import {
  Search,
  SlidersHorizontal,
  X,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { Product, Category } from "@shared/schema";
import ProductCard from "@/components/product/ProductCard";
import { QuickViewModal } from "@/components/product/QuickViewModal";
import { withCart } from "@/hooks/useCart";

interface FilterSection {
  id: string;
  title: string;
  expanded: boolean;
  content: React.ReactNode;
}

const ProductListing = () => {
  const [_, params] = useRoute("/category/:slug");
  const [location] = useLocation();
  const [filterSidebarOpen, setFilterSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isQuickViewOpen, setIsQuickViewOpen] = useState(false);

  // Parse query params
  const urlParams = new URLSearchParams(location.split("?")[1] || "");
  const isNewArrival = urlParams.get("isNewArrival") === "true";
  const isSale = urlParams.get("isSale") === "true";
  const search = urlParams.get("search") || "";

  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Find the current category if we're on a category page
  useEffect(() => {
    if (params?.slug && categories) {
      const category = categories.find(cat => cat.slug === params.slug);
      if (category) {
        setSelectedCategory(category.id);
      }
    } else if (!params?.slug) {
      setSelectedCategory(null);
    }
  }, [params?.slug, categories]);

  // Fetch products with filters
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', { categoryId: selectedCategory, isNewArrival, isSale, search: searchQuery || search }],
  });

  // Filter sections
  const [filterSections, setFilterSections] = useState<FilterSection[]>([
    {
      id: "categories",
      title: "Categories",
      expanded: true,
      content: (
        <div className="space-y-2">
          {categories?.map((category) => (
            <div key={category.id} className="flex items-center">
              <input
                type="checkbox"
                id={`category-${category.id}`}
                checked={selectedCategory === category.id}
                onChange={() => setSelectedCategory(category.id === selectedCategory ? null : category.id)}
                className="mr-2"
              />
              <label htmlFor={`category-${category.id}`}>{category.name}</label>
            </div>
          ))}
        </div>
      ),
    },
    {
      id: "price",
      title: "Price Range",
      expanded: true,
      content: (
        <div className="space-y-4">
          <div className="flex justify-between">
            <span>${priceRange[0]}</span>
            <span>${priceRange[1]}</span>
          </div>
          <input
            type="range"
            min="0"
            max="500"
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
            className="w-full"
          />
        </div>
      ),
    },
    {
      id: "size",
      title: "Size",
      expanded: false,
      content: (
        <div className="grid grid-cols-2 gap-2">
          {["XS", "S", "M", "L", "XL", "XXL"].map((size) => (
            <div key={size} className="flex items-center">
              <input
                type="checkbox"
                id={`size-${size}`}
                className="mr-2"
              />
              <label htmlFor={`size-${size}`}>{size}</label>
            </div>
          ))}
        </div>
      ),
    },
    {
      id: "color",
      title: "Color",
      expanded: false,
      content: (
        <div className="flex flex-wrap gap-2">
          {["Black", "White", "Red", "Blue", "Green", "Yellow", "Purple", "Pink"].map((color) => (
            <div key={color} className="flex items-center">
              <input
                type="checkbox"
                id={`color-${color}`}
                className="mr-2"
              />
              <label htmlFor={`color-${color}`}>{color}</label>
            </div>
          ))}
        </div>
      ),
    },
  ]);

  const toggleFilterSection = (id: string) => {
    setFilterSections(
      filterSections.map((section) =>
        section.id === id
          ? { ...section, expanded: !section.expanded }
          : section
      )
    );
  };

  const openQuickView = (product: Product) => {
    setQuickViewProduct(product);
    setIsQuickViewOpen(true);
  };

  const closeQuickView = () => {
    setIsQuickViewOpen(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The query will automatically update with the search param
  };

  // Page title based on current filters
  let pageTitle = "Shop All Products";
  if (params?.slug && categories) {
    const category = categories.find(cat => cat.slug === params.slug);
    if (category) {
      pageTitle = category.name;
    }
  } else if (isNewArrival) {
    pageTitle = "New Arrivals";
  } else if (isSale) {
    pageTitle = "Sale Items";
  } else if (search) {
    pageTitle = `Search Results: "${search}"`;
  }

  return (
    <>
      <Helmet>
        <title>{pageTitle} | Elegance</title>
        <meta name="description" content={`Shop our collection of ${pageTitle.toLowerCase()} at Elegance. Find the latest trends in women's fashion.`} />
      </Helmet>

      <div className="bg-neutral py-6">
        <div className="container mx-auto px-4">
          <h1 className="font-playfair text-3xl font-bold text-center">{pageTitle}</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => setFilterSidebarOpen(true)}
            className="flex items-center text-sm md:hidden"
          >
            <SlidersHorizontal size={18} className="mr-2" /> Filter
          </button>

          <form onSubmit={handleSearch} className="flex items-center border border-gray-300 rounded-sm max-w-md w-full ml-auto">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products..."
              className="px-4 py-2 w-full focus:outline-none"
            />
            <button type="submit" className="p-2 text-gray-500">
              <Search size={18} />
            </button>
          </form>
        </div>

        <div className="flex flex-wrap -mx-4">
          {/* Filter Sidebar for Desktop */}
          <div className="hidden md:block w-full md:w-1/4 px-4">
            <div className="bg-white p-4 rounded-sm shadow-sm">
              <h2 className="font-medium text-lg mb-4">Filters</h2>

              {filterSections.map((section) => (
                <div key={section.id} className="mb-4 border-b pb-2">
                  <button
                    onClick={() => toggleFilterSection(section.id)}
                    className="filter-header w-full flex justify-between items-center font-medium py-2"
                  >
                    {section.title}
                    {section.expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  </button>
                  <div className={section.expanded ? "mt-2" : "hidden"}>
                    {section.content}
                  </div>
                </div>
              ))}

              <button className="bg-primary text-white w-full py-2 rounded-sm mt-4">
                Apply Filters
              </button>
            </div>
          </div>

          {/* Product Grid */}
          <div className="w-full md:w-3/4 px-4">
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="bg-white rounded-sm shadow-sm overflow-hidden animate-pulse">
                    <div className="h-[350px] bg-neutral-light"></div>
                    <div className="p-4">
                      <div className="h-6 bg-neutral-light w-3/4 mb-2"></div>
                      <div className="h-5 bg-neutral-light w-1/4 mb-4"></div>
                      <div className="h-10 bg-neutral-light w-full"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : products && products.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    openQuickView={openQuickView}
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-sm p-8 text-center">
                <p className="text-lg mb-4">No products found.</p>
                <p className="text-gray-500">Try adjusting your filters or search term.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Filter Sidebar */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden ${
          filterSidebarOpen ? "block" : "hidden"
        }`}
        onClick={() => setFilterSidebarOpen(false)}
      ></div>

      <div
        id="filter-sidebar"
        className={`fixed top-0 left-0 h-full w-3/4 bg-white z-50 transform ${
          filterSidebarOpen ? "translate-x-0" : "-translate-x-full"
        } transition-transform duration-300 ease-in-out md:hidden overflow-y-auto`}
      >
        <div className="p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-medium text-lg">Filters</h2>
            <button
              id="close-filter"
              onClick={() => setFilterSidebarOpen(false)}
              className="text-gray-500"
            >
              <X size={20} />
            </button>
          </div>

          {filterSections.map((section) => (
            <div key={section.id} className="mb-4 border-b pb-2">
              <button
                onClick={() => toggleFilterSection(section.id)}
                className="filter-header w-full flex justify-between items-center font-medium py-2"
              >
                {section.title}
                {section.expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              </button>
              <div className={section.expanded ? "mt-2" : "hidden"}>
                {section.content}
              </div>
            </div>
          ))}

          <button
            onClick={() => setFilterSidebarOpen(false)}
            className="bg-primary text-white w-full py-2 rounded-sm mt-4"
          >
            Apply Filters
          </button>
        </div>
      </div>

      <QuickViewModal
        isOpen={isQuickViewOpen}
        onClose={closeQuickView}
        product={quickViewProduct}
      />
    </>
  );
};

export default withCart(ProductListing);
