import { useState, useEffect } from 'react';
import { useSearch } from 'wouter';
import { MainLayout } from '@/components/layouts/main-layout';
import { ProductCard } from '@/components/ui/product-card';
import { FilterSidebar } from '@/components/ui/filter-sidebar';
import { QuickViewModal } from '@/components/ui/quick-view-modal';
import { Button } from '@/components/ui/button';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { DEFAULT_PAGE_SIZE, SORT_OPTIONS, PRICE_RANGE } from '@/lib/constants';
import { LayoutGrid, LayoutList, SlidersHorizontal } from 'lucide-react';
import { ProductWithCategory } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from '@/components/ui/pagination';

export default function Products() {
  const [searchParams] = useSearch();
  const queryParams = new URLSearchParams(searchParams);
  
  // State for sidebar on mobile
  const [filterOpen, setFilterOpen] = useState(false);
  
  // State for active view mode
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  
  // State for product modal
  const [quickViewProduct, setQuickViewProduct] = useState<ProductWithCategory | null>(null);
  
  // Get current category from URL or default to 'all'
  const urlCategoryId = queryParams.get('categoryId') || 'all';
  const [activeCategory, setActiveCategory] = useState(urlCategoryId);
  
  // Get other filter params
  const [sortOption, setSortOption] = useState(queryParams.get('sort') || 'featured');
  const [currentPage, setCurrentPage] = useState(parseInt(queryParams.get('page') || '1'));
  const [filters, setFilters] = useState({
    price: [
      parseInt(queryParams.get('minPrice') || PRICE_RANGE.MIN.toString()),
      parseInt(queryParams.get('maxPrice') || PRICE_RANGE.MAX.toString())
    ] as [number, number],
    rating: parseInt(queryParams.get('minRating') || '0'),
    inStock: queryParams.get('inStock') === 'true'
  });
  
  // Build query string for API
  const buildQueryString = () => {
    const params = new URLSearchParams();
    
    // Pagination
    params.append('limit', DEFAULT_PAGE_SIZE.toString());
    params.append('offset', ((currentPage - 1) * DEFAULT_PAGE_SIZE).toString());
    
    // Category filter
    if (activeCategory !== 'all') {
      params.append('categoryId', activeCategory);
    }
    
    // Price filter
    if (filters.price[0] > PRICE_RANGE.MIN) {
      params.append('minPrice', filters.price[0].toString());
    }
    if (filters.price[1] < PRICE_RANGE.MAX) {
      params.append('maxPrice', filters.price[1].toString());
    }
    
    // Rating filter
    if (filters.rating > 0) {
      params.append('minRating', filters.rating.toString());
    }
    
    // Availability filter
    if (filters.inStock) {
      params.append('inStock', 'true');
    }
    
    // Sort
    if (sortOption === 'price_asc') {
      params.append('sort', 'price');
      params.append('order', 'asc');
    } else if (sortOption === 'price_desc') {
      params.append('sort', 'price');
      params.append('order', 'desc');
    } else if (sortOption === 'newest') {
      params.append('sort', 'id');
      params.append('order', 'desc');
    } else if (sortOption === 'rating') {
      params.append('sort', 'rating');
      params.append('order', 'desc');
    }
    
    // Featured products
    if (queryParams.get('featured') === 'true') {
      params.append('featured', 'true');
    }
    
    // Search query
    if (queryParams.get('search')) {
      params.append('search', queryParams.get('search')!);
    }
    
    return params.toString();
  };
  
  // Update URL when filters change
  useEffect(() => {
    const newParams = new URLSearchParams(searchParams);
    
    // Update category
    if (activeCategory !== 'all') {
      newParams.set('categoryId', activeCategory);
    } else {
      newParams.delete('categoryId');
    }
    
    // Update price
    if (filters.price[0] > PRICE_RANGE.MIN) {
      newParams.set('minPrice', filters.price[0].toString());
    } else {
      newParams.delete('minPrice');
    }
    
    if (filters.price[1] < PRICE_RANGE.MAX) {
      newParams.set('maxPrice', filters.price[1].toString());
    } else {
      newParams.delete('maxPrice');
    }
    
    // Update rating
    if (filters.rating > 0) {
      newParams.set('minRating', filters.rating.toString());
    } else {
      newParams.delete('minRating');
    }
    
    // Update availability
    if (filters.inStock) {
      newParams.set('inStock', 'true');
    } else {
      newParams.delete('inStock');
    }
    
    // Update sort
    if (sortOption !== 'featured') {
      newParams.set('sort', sortOption);
    } else {
      newParams.delete('sort');
    }
    
    // Update page
    if (currentPage > 1) {
      newParams.set('page', currentPage.toString());
    } else {
      newParams.delete('page');
    }
    
    // Update URL without reloading page
    const newUrl = `${window.location.pathname}?${newParams.toString()}`;
    window.history.pushState(null, '', newUrl);
  }, [activeCategory, filters, sortOption, currentPage]);
  
  // Fetch products with filters
  const { data, isLoading, refetch } = useQuery({
    queryKey: [`/api/products?${buildQueryString()}`],
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    staleTime: 5000, // Consider data stale after 5 seconds
  });
  
  // Safely extract products and total from data
  const products = data && typeof data === 'object' && 'products' in data ? data.products : [];
  const totalProducts = data && typeof data === 'object' && 'meta' in data && data.meta && typeof data.meta === 'object' && 'total' in data.meta ? data.meta.total : 0;
  const totalPages = Math.ceil(totalProducts / DEFAULT_PAGE_SIZE);
  
  // Fetch categories
  const { data: categoriesData } = useQuery({
    queryKey: ['/api/categories'],
  });
  
  const categories = categoriesData || [];
  
  // Handle category change
  const handleCategoryChange = (categoryId: string) => {
    setActiveCategory(categoryId);
    setCurrentPage(1);
  };
  
  // Handle filter change
  const handleFilterChange = (name: string, value: any) => {
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Apply filters
  const handleApplyFilters = () => {
    refetch();
    setFilterOpen(false);
  };
  
  // Clear filters
  const handleClearFilters = () => {
    setFilters({
      price: [PRICE_RANGE.MIN, PRICE_RANGE.MAX],
      rating: 0,
      inStock: false
    });
    refetch();
  };
  
  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };
  
  // Open quick view modal
  const handleQuickView = (product: ProductWithCategory) => {
    setQuickViewProduct(product);
  };
  
  return (
    <MainLayout>
      <section className="py-10 bg-slate-50">
        <div className="container mx-auto px-4 max-w-7xl">
          {/* Section Header with Filter Trigger */}
          <div className="flex flex-wrap justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-slate-900">
              {queryParams.get('search') 
                ? `Search results for "${queryParams.get('search')}"` 
                : queryParams.get('featured') === 'true'
                  ? 'Featured Products'
                  : categories.find(c => c.id.toString() === activeCategory)?.name || 'All Products'
              }
            </h1>
            <Button 
              variant="outline" 
              size="sm" 
              className="lg:hidden flex items-center space-x-2"
              onClick={() => setFilterOpen(!filterOpen)}
            >
              <SlidersHorizontal className="h-4 w-4" />
              <span>Filters</span>
            </Button>
          </div>
          
          <div className="flex flex-col lg:flex-row">
            {/* Filter Sidebar */}
            <FilterSidebar 
              open={filterOpen}
              onOpenChange={setFilterOpen}
              activeCategory={activeCategory}
              onCategoryChange={handleCategoryChange}
              filters={filters}
              onFilterChange={handleFilterChange}
              onApplyFilters={handleApplyFilters}
              onClearFilters={handleClearFilters}
              className="lg:w-64 lg:mr-6 max-h-[80vh]"
            />
            
            {/* Product Grid */}
            <div className="flex-1">
              {/* Sort & View Controls */}
              <div className="flex flex-wrap justify-between items-center mb-6 bg-white p-3 rounded-md shadow-sm">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-slate-500">Sort by:</span>
                  <Select value={sortOption} onValueChange={(value) => setSortOption(value)}>
                    <SelectTrigger className="w-[180px] h-8 text-sm">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      {SORT_OPTIONS.map(option => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 mt-2 sm:mt-0">
                  <span className="text-sm text-slate-500">View:</span>
                  <Button 
                    variant={viewMode === 'grid' ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-8 w-8" 
                    onClick={() => setViewMode('grid')}
                  >
                    <LayoutGrid className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant={viewMode === 'list' ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-8 w-8" 
                    onClick={() => setViewMode('list')}
                  >
                    <LayoutList className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              {/* Loading State */}
              {isLoading && (
                <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'} gap-4`}>
                  {[...Array(8)].map((_, index) => (
                    <div key={index} className="bg-white rounded-md shadow-sm p-4 h-80 animate-pulse">
                      <div className="w-full h-40 bg-slate-200 rounded-md mb-4"></div>
                      <div className="h-4 bg-slate-200 rounded mb-2"></div>
                      <div className="h-4 bg-slate-200 rounded w-3/4 mb-4"></div>
                      <div className="h-6 bg-slate-200 rounded w-1/4 mb-4"></div>
                      <div className="flex justify-between">
                        <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                        <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {/* No Results */}
              {!isLoading && products.length === 0 && (
                <div className="bg-white rounded-md shadow-sm p-8 text-center">
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">No products found</h3>
                  <p className="text-slate-600 mb-4">Try adjusting your filters or search criteria.</p>
                  <Button onClick={handleClearFilters}>Clear Filters</Button>
                </div>
              )}
              
              {/* Products Grid */}
              {!isLoading && products.length > 0 && (
                <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'} gap-4`}>
                  {products.map((product: ProductWithCategory) => (
                    <ProductCard 
                      key={product.id}
                      product={product}
                      onQuickView={handleQuickView}
                    />
                  ))}
                </div>
              )}
              
              {/* Pagination */}
              {!isLoading && totalPages > 1 && (
                <div className="mt-8 flex justify-center">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious 
                          onClick={() => currentPage > 1 && handlePageChange(currentPage - 1)}
                          className={currentPage <= 1 ? 'pointer-events-none opacity-50' : ''}
                        />
                      </PaginationItem>
                      
                      {[...Array(totalPages)].map((_, index) => {
                        const pageNumber = index + 1;
                        
                        // Show first page, current page, last page, and pages around current page
                        if (
                          pageNumber === 1 ||
                          pageNumber === totalPages ||
                          (pageNumber >= currentPage - 1 && pageNumber <= currentPage + 1)
                        ) {
                          return (
                            <PaginationItem key={pageNumber}>
                              <PaginationLink
                                onClick={() => handlePageChange(pageNumber)}
                                isActive={pageNumber === currentPage}
                              >
                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>
                          );
                        }
                        
                        // Show ellipsis for breaks in sequence
                        if (
                          (pageNumber === 2 && currentPage > 3) ||
                          (pageNumber === totalPages - 1 && currentPage < totalPages - 2)
                        ) {
                          return (
                            <PaginationItem key={pageNumber}>
                              <PaginationEllipsis />
                            </PaginationItem>
                          );
                        }
                        
                        return null;
                      })}
                      
                      <PaginationItem>
                        <PaginationNext 
                          onClick={() => currentPage < totalPages && handlePageChange(currentPage + 1)}
                          className={currentPage >= totalPages ? 'pointer-events-none opacity-50' : ''}
                        />
                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
      
      {/* Quick View Modal */}
      <QuickViewModal 
        product={quickViewProduct} 
        open={!!quickViewProduct} 
        onOpenChange={(open) => !open && setQuickViewProduct(null)} 
      />
    </MainLayout>
  );
}
