import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { MainLayout } from '@/components/layouts/main-layout';
import { ProductCard } from '@/components/ui/product-card';
import { QuickViewModal } from '@/components/ui/quick-view-modal';
import { Button } from '@/components/ui/button';
import { CATEGORY_IMAGES, COMPANY_FEATURES } from '@/lib/constants';
import { ProductWithCategory } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import { Truck, RotateCcw, ShieldCheck, Headphones, LayoutDashboard } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

export default function Home() {
  const [quickViewProduct, setQuickViewProduct] = useState<ProductWithCategory | null>(null);
  const { user, isAdmin } = useAuth();
  
  // Fetch featured products
  const { data: featuredProductsData, isLoading: featuredLoading } = useQuery({
    queryKey: ['/api/products', { featured: true, limit: 8 }],
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    staleTime: 5000, // Consider data stale after 5 seconds
  });
  
  // Get featured products
  const featuredProducts = (featuredProductsData as any)?.products || [];
  
  console.log("Featured products data:", featuredProductsData);
  console.log("Featured products:", featuredProducts);

  // Fetch new arrivals
  const { data: newArrivalsData, isLoading: newArrivalsLoading } = useQuery({
    queryKey: ['/api/products', { sort: 'newest', limit: 8 }],
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });
  
  // Get new arrivals
  const newArrivals = (newArrivalsData as any)?.products || [];
  
  console.log("New arrivals data:", newArrivalsData);
  console.log("New arrivals:", newArrivals);

  // Get categories
  const { data: categoriesData } = useQuery({
    queryKey: ['/api/categories'],
  });
  
  const categories = Array.isArray(categoriesData) ? categoriesData : [];

  // Open quick view modal
  const handleQuickView = (product: ProductWithCategory) => {
    setQuickViewProduct(product);
  };

  return (
    <MainLayout>
      {/* Admin Banner - Only visible to admins */}
      {isAdmin && (
        <section className="bg-amber-50 border-b border-amber-200">
          <div className="container mx-auto px-4 max-w-7xl py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <LayoutDashboard className="h-5 w-5 text-amber-600" />
                <span className="font-medium text-amber-800">Admin Access Granted</span>
              </div>
              <Link href="/admin">
                <Button className="bg-amber-600 hover:bg-amber-700">
                  <LayoutDashboard className="h-4 w-4 mr-2" />
                  Admin Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </section>
      )}
      
      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-slate-800 to-slate-900 text-white py-12 md:py-20">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight">New Season Collection</h1>
              <p className="text-slate-300 text-lg max-w-md">Discover the latest trends and find your perfect style for this season.</p>
              <div className="flex space-x-4">
                <Link href="/products">
                  <Button size="lg" className="px-6">Shop Now</Button>
                </Link>
                <Link href="/products?featured=true">
                  <Button size="lg" variant="outline" className="px-6 bg-white/10 hover:bg-white/20 text-white border-transparent">
                    Learn More
                  </Button>
                </Link>
                {isAdmin && (
                  <Link href="/admin">
                    <Button size="lg" variant="outline" className="px-6 bg-amber-500/90 hover:bg-amber-500 text-white border-transparent">
                      <LayoutDashboard className="h-4 w-4 mr-2" />
                      Admin
                    </Button>
                  </Link>
                )}
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800&q=80" 
                alt="Fashion model showcasing new collection" 
                className="rounded-md shadow-xl object-cover w-full h-[400px]"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Featured Categories */}
      <section className="py-12">
        <div className="container mx-auto px-4 max-w-7xl">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category: any) => (
              <Link key={category.id} href={`/products?categoryId=${category.id}`}>
                <a className="relative group overflow-hidden rounded-md shadow-md aspect-square">
                  <img 
                    src={category.image || (category.name && CATEGORY_IMAGES[category.name.toLowerCase() as keyof typeof CATEGORY_IMAGES]) || CATEGORY_IMAGES.all} 
                    alt={category.name} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent"></div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <div className="text-white font-medium">{category.name}</div>
                    <div className="text-white/80 text-sm">Explore collection</div>
                  </div>
                </a>
              </Link>
            ))}
          </div>
        </div>
      </section>
      
      {/* Featured Products */}
      <section className="py-10 bg-slate-50">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">Featured Products</h2>
            <Link href="/products?featured=true">
              <Button variant="link">View All</Button>
            </Link>
          </div>
          
          {featuredLoading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, index) => (
                <div key={index} className="bg-white rounded-md shadow-sm p-4 h-80 animate-pulse">
                  <div className="w-full h-40 bg-slate-200 rounded-md mb-4"></div>
                  <div className="h-4 bg-slate-200 rounded mb-2"></div>
                  <div className="h-4 bg-slate-200 rounded w-3/4 mb-4"></div>
                  <div className="h-6 bg-slate-200 rounded w-1/4 mb-4"></div>
                  <div className="flex justify-between">
                    <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                    <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : featuredProducts.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {featuredProducts.map((product: any) => (
                <ProductCard 
                  key={product.id}
                  product={product}
                  onQuickView={handleQuickView}
                />
              ))}
            </div>
          ) : (
            <div className="text-center p-8 bg-white rounded-md">
              <p className="text-slate-500">No featured products available at the moment.</p>
              {isAdmin && (
                <Link href="/admin/products/new">
                  <Button className="mt-4">Add Products</Button>
                </Link>
              )}
            </div>
          )}
        </div>
      </section>
      
      {/* New Arrivals */}
      <section className="py-10 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900">New Arrivals</h2>
            <Link href="/products?sort=newest">
              <Button variant="link">View All</Button>
            </Link>
          </div>
          
          {newArrivalsLoading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, index) => (
                <div key={index} className="bg-slate-50 rounded-md shadow-sm p-4 h-80 animate-pulse">
                  <div className="w-full h-40 bg-slate-200 rounded-md mb-4"></div>
                  <div className="h-4 bg-slate-200 rounded mb-2"></div>
                  <div className="h-4 bg-slate-200 rounded w-3/4 mb-4"></div>
                  <div className="h-6 bg-slate-200 rounded w-1/4 mb-4"></div>
                  <div className="flex justify-between">
                    <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                    <div className="h-8 bg-slate-200 rounded w-1/3"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : newArrivals.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {newArrivals.map((product: any) => (
                <ProductCard 
                  key={product.id}
                  product={product}
                  onQuickView={handleQuickView}
                />
              ))}
            </div>
          ) : (
            <div className="text-center p-8 bg-slate-50 rounded-md">
              <p className="text-slate-500">No new arrivals available at the moment.</p>
              {isAdmin && (
                <Link href="/admin/products/new">
                  <Button className="mt-4">Add Products</Button>
                </Link>
              )}
            </div>
          )}
        </div>
      </section>
      
      {/* Special Offers Banner */}
      <section className="py-10 bg-white">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gradient-to-r from-blue-500 to-violet-500 rounded-lg p-6 flex flex-col justify-between text-white h-64">
              <div>
                <div className="text-sm uppercase tracking-wider">Limited Time Offer</div>
                <h3 className="text-2xl font-bold mt-2">End of Season Sale</h3>
                <p className="mt-1 opacity-90">Get up to 50% off on selected items</p>
              </div>
              <Link href="/products?sale=true">
                <Button className="self-start mt-4 bg-white text-blue-600 hover:bg-blue-50">Shop Now</Button>
              </Link>
            </div>
            <div className="bg-gradient-to-r from-amber-500 to-red-500 rounded-lg p-6 flex flex-col justify-between text-white h-64">
              <div>
                <div className="text-sm uppercase tracking-wider">New Arrivals</div>
                <h3 className="text-2xl font-bold mt-2">Summer Collection 2023</h3>
                <p className="mt-1 opacity-90">Discover the hottest trends</p>
              </div>
              <Link href="/products?featured=true">
                <Button className="self-start mt-4 bg-white text-amber-600 hover:bg-amber-50">Explore</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Customer Reviews */}
      <section className="py-12 bg-slate-50">
        <div className="container mx-auto px-4 max-w-7xl">
          <h2 className="text-2xl font-bold text-slate-900 mb-8 text-center">What Our Customers Say</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex text-amber-400 mb-3">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-4 h-4 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                ))}
              </div>
              <p className="text-slate-700 mb-4">"The quality of the products is outstanding. I've ordered multiple times and have always been impressed with the fast shipping and service."</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden mr-3">
                  <img src="https://randomuser.me/api/portraits/women/45.jpg" alt="Sarah T." className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="font-medium text-slate-900">Sarah T.</div>
                  <div className="text-xs text-slate-500">Verified Buyer</div>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex text-amber-400 mb-3">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-4 h-4 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                ))}
              </div>
              <p className="text-slate-700 mb-4">"ShopWave has become my go-to store for electronics. Their customer service is top-notch, and they always have the latest tech at competitive prices."</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden mr-3">
                  <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Michael R." className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="font-medium text-slate-900">Michael R.</div>
                  <div className="text-xs text-slate-500">Verified Buyer</div>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex text-amber-400 mb-3">
                {[...Array(4)].map((_, i) => (
                  <svg key={i} className="w-4 h-4 fill-current" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                ))}
                <svg className="w-4 h-4 stroke-current fill-none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.519 4.674c.3.921-.755 1.688-1.54 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.784.57-1.838-.197-1.539-1.118l1.519-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
                </svg>
              </div>
              <p className="text-slate-700 mb-4">"I love the variety of products available. The website is easy to navigate, and checkout is always smooth. Would definitely recommend to friends."</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden mr-3">
                  <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Jessica K." className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="font-medium text-slate-900">Jessica K.</div>
                  <div className="text-xs text-slate-500">Verified Buyer</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features */}
      <section className="py-10 bg-white border-t border-slate-200">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {COMPANY_FEATURES.map((feature, index) => {
              const IconComponent = {
                'Truck': Truck,
                'RotateCcw': RotateCcw,
                'ShieldCheck': ShieldCheck,
                'Headphones': Headphones
              }[feature.icon];
              
              return (
                <div key={index} className="flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center text-primary mb-3">
                    {IconComponent && <IconComponent className="h-6 w-6" />}
                  </div>
                  <h3 className="font-medium text-slate-900 mb-1">{feature.title}</h3>
                  <p className="text-sm text-slate-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* Quick View Modal */}
      <QuickViewModal 
        product={quickViewProduct} 
        open={!!quickViewProduct} 
        onOpenChange={(open) => !open && setQuickViewProduct(null)} 
      />
    </MainLayout>
  );
}
