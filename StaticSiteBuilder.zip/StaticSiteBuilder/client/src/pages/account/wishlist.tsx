import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { MainLayout } from '@/components/layouts/main-layout';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { ProductWithCategory } from '@shared/schema';
import { useCart } from '@/hooks/use-cart';
import { Heart, ShoppingCart, Package2, Trash2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { DEFAULT_PRODUCT_IMAGE } from '@/lib/constants';

export default function Wishlist() {
  const { toast } = useToast();
  const { addItem } = useCart();
  
  // For demo purposes, we're using local storage to store the wishlist
  // In a real application, this would be stored in a database
  const [wishlist, setWishlist] = useState<ProductWithCategory[]>(() => {
    if (typeof window === 'undefined') return [];
    const saved = localStorage.getItem('wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  const removeFromWishlist = (productId: number) => {
    const updatedWishlist = wishlist.filter(item => item.id !== productId);
    setWishlist(updatedWishlist);
    localStorage.setItem('wishlist', JSON.stringify(updatedWishlist));
    toast({
      title: "Removed from wishlist",
      description: "Item has been removed from your wishlist",
    });
  };

  const handleAddToCart = async (product: ProductWithCategory) => {
    try {
      await addItem(product.id);
      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not add item to cart",
        variant: "destructive",
      });
    }
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 max-w-7xl py-10">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">My Wishlist</h1>
        
        {wishlist.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="h-8 w-8 text-slate-400" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Your Wishlist is Empty</h2>
              <p className="text-slate-600 mb-6">Items added to your wishlist will appear here</p>
              <Button asChild>
                <Link href="/products">Start Shopping</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {wishlist.map((product) => (
              <div key={product.id} className="bg-white rounded-md shadow-sm overflow-hidden group">
                <div className="relative">
                  <img
                    src={product.imageUrl || DEFAULT_PRODUCT_IMAGE}
                    alt={product.name}
                    className="w-full h-60 object-cover object-center"
                  />
                  <div className="absolute top-2 right-2">
                    <Button
                      variant="destructive"
                      size="icon"
                      className="h-8 w-8 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => removeFromWishlist(product.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="p-4">
                  <Link href={`/products/${product.id}`}>
                    <a className="text-lg font-semibold text-slate-900 hover:text-primary">
                      {product.name}
                    </a>
                  </Link>
                  
                  <div className="text-sm text-slate-500 mb-2">
                    {product.category?.name}
                  </div>
                  
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center">
                      <span className="text-lg font-semibold text-slate-900">
                        ${Number(product.price).toFixed(2)}
                      </span>
                      {product.salePrice && (
                        <span className="ml-2 text-sm line-through text-slate-500">
                          ${Number(product.salePrice).toFixed(2)}
                        </span>
                      )}
                    </div>
                    
                    <Button 
                      size="sm" 
                      className="h-9"
                      onClick={() => handleAddToCart(product)}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Add
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}