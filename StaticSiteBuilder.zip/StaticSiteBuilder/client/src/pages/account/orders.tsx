import { MainLayout } from '@/components/layouts/main-layout';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { OrderWithItems } from '@shared/schema';
import { DEFAULT_PRODUCT_IMAGE } from '@/lib/constants';
import { FileType, EyeOff, Package2, Truck, CircleX, CircleEqual } from 'lucide-react';

// Helper function to format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }).format(date);
};

// Helper function to get status badge color
const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case 'pending':
      return 'bg-amber-100 text-amber-800';
    case 'processing':
      return 'bg-blue-100 text-blue-800';
    case 'shipped':
      return 'bg-purple-100 text-purple-800';
    case 'delivered':
      return 'bg-green-100 text-green-800';
    case 'cancelled':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-slate-100 text-slate-800';
  }
};

// Helper function to get status icon
const StatusIcon = ({ status }: { status: string }) => {
  switch (status.toLowerCase()) {
    case 'pending':
      return <FileType className="h-5 w-5 text-amber-500" />;
    case 'processing':
      return <Package2 className="h-5 w-5 text-blue-500" />;
    case 'shipped':
      return <Truck className="h-5 w-5 text-purple-500" />;
    case 'delivered':
      return <CircleX className="h-5 w-5 text-green-500" />;
    case 'cancelled':
      return <CircleEqual className="h-5 w-5 text-red-500" />;
    default:
      return <FileType className="h-5 w-5 text-slate-500" />;
  }
};

export default function Orders() {
  // Mock user ID for demonstration (in a real app, would come from authentication)
  const userId = 1;
  
  // Fetch orders for the user
  const { data: orders, isLoading, error } = useQuery<OrderWithItems[]>({
    queryKey: [`/api/orders?userId=${userId}`],
  });

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 max-w-7xl py-10">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-slate-200 rounded w-1/4"></div>
            <div className="h-64 bg-slate-200 rounded"></div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (error || !orders) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 max-w-7xl py-10">
          <div className="bg-white p-8 rounded-md shadow-sm text-center">
            <h1 className="text-2xl font-bold text-slate-900 mb-4">Error Loading Orders</h1>
            <p className="text-slate-600 mb-6">We couldn't load your order history. Please try again later.</p>
            <Button onClick={() => window.location.reload()}>Try Again</Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 max-w-7xl py-10">
        <h1 className="text-2xl font-bold text-slate-900 mb-6">My Orders</h1>
        
        {orders.length === 0 ? (
          <Card>
            <CardContent className="pt-6 text-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package2 className="h-8 w-8 text-slate-400" />
              </div>
              <h2 className="text-xl font-semibold mb-2">No Orders Yet</h2>
              <p className="text-slate-600 mb-6">You haven't placed any orders yet.</p>
              <Button asChild>
                <Link href="/products">Start Shopping</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => (
              <Accordion 
                key={order.id} 
                type="single" 
                collapsible 
                className="bg-white rounded-md shadow-sm overflow-hidden"
              >
                <AccordionItem value={`order-${order.id}`} className="border-none">
                  <AccordionTrigger className="px-6 py-4 hover:no-underline">
                    <div className="flex flex-col md:flex-row md:items-center justify-between w-full text-left">
                      <div className="flex items-center">
                        <StatusIcon status={order.status} />
                        <div className="ml-4">
                          <div className="font-medium">Order #{order.id}</div>
                          <div className="text-sm text-slate-500">
                            {order.createdAt ? formatDate(order.createdAt.toString()) : 'N/A'}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center mt-2 md:mt-0">
                        <Badge className={`mr-4 ${getStatusColor(order.status)}`}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </Badge>
                        <div className="font-medium">${Number(order.total).toFixed(2)}</div>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="px-6 pb-6">
                      <div className="mb-4">
                        <h3 className="font-medium text-slate-900 mb-2">Order Items</h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Product</TableHead>
                              <TableHead className="text-right">Price</TableHead>
                              <TableHead className="text-right">Quantity</TableHead>
                              <TableHead className="text-right">Total</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {order.items?.map((item) => (
                              <TableRow key={item.id}>
                                <TableCell>
                                  <div className="flex items-center">
                                    <div className="w-12 h-12 bg-slate-100 rounded overflow-hidden mr-3">
                                      <img 
                                        src={item.product.imageUrl || DEFAULT_PRODUCT_IMAGE} 
                                        alt={item.product.name} 
                                        className="w-full h-full object-contain"
                                      />
                                    </div>
                                    <div>
                                      <Link href={`/products/${item.productId}`}>
                                        <a className="font-medium text-slate-900 hover:text-primary">
                                          {item.product.name}
                                        </a>
                                      </Link>
                                      <div className="text-sm text-slate-500">
                                        {item.product.category?.name || 'N/A'}
                                      </div>
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell className="text-right">${Number(item.price).toFixed(2)}</TableCell>
                                <TableCell className="text-right">{item.quantity}</TableCell>
                                <TableCell className="text-right font-medium">
                                  ${(Number(item.price) * item.quantity).toFixed(2)}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h3 className="font-medium text-slate-900 mb-2">Shipping Address</h3>
                          <div className="bg-slate-50 p-4 rounded-md">
                            <p className="text-slate-700">
                              {order.address}<br />
                              {order.city}, {order.state} {order.postalCode}<br />
                              {order.country}<br />
                              {order.phone}
                            </p>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="font-medium text-slate-900 mb-2">Order Summary</h3>
                          <div className="bg-slate-50 p-4 rounded-md space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-slate-600">Subtotal</span>
                              <span>${(Number(order.total) - 5.99).toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-slate-600">Shipping</span>
                              <span>$5.99</span>
                            </div>
                            <Separator className="my-2" />
                            <div className="flex justify-between font-medium">
                              <span>Total</span>
                              <span>${Number(order.total).toFixed(2)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-6 flex justify-end">
                        <Button variant="outline" size="sm" className="mr-2">
                          <EyeOff className="mr-2 h-4 w-4" />
                          Track Order
                        </Button>
                        <Button variant="secondary" size="sm">
                          <FileType className="mr-2 h-4 w-4" />
                          View Invoice
                        </Button>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
