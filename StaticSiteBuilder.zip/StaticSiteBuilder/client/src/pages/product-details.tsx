import { useState, useEffect } from 'react';
import { useParams, Link } from 'wouter';
import { MainLayout } from '@/components/layouts/main-layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/hooks/use-cart';
import { Heart, Share2, Truck, RotateCcw, ShieldCheck, MinusCircle, PlusCircle } from 'lucide-react';
import { DEFAULT_PRODUCT_IMAGE } from '@/lib/constants';
import { useQuery } from '@tanstack/react-query';
import { ProductWithCategory } from '@shared/schema';

export default function ProductDetails() {
  const params = useParams();
  const { id } = params;
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();
  const { addItem, isLoading: cartLoading } = useCart();
  
  // Fetch product details
  const { data: productData, isLoading, error } = useQuery({
    queryKey: [`/api/products/${id}`],
  });
  
  const product = productData?.product;
  
  // Fetch related products
  const { data: relatedData } = useQuery({
    queryKey: [`/api/products?limit=4${product ? `&categoryId=${product.categoryId}` : ''}`],
    enabled: !!product,
  });
  
  const relatedProducts = relatedData?.products || [];
  
  // Handle quantity changes
  const increaseQuantity = () => {
    if (product && quantity < product.inventory) {
      setQuantity(quantity + 1);
    }
  };
  
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value >= 1 && product && value <= product.inventory) {
      setQuantity(value);
    }
  };
  
  // Add to cart
  const handleAddToCart = () => {
    if (product) {
      addItem(product.id, quantity);
    }
  };
  
  // Share product
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product?.name,
        text: product?.description,
        url: window.location.href,
      }).catch((error) => {
        console.log('Error sharing', error);
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied",
        description: "Product link copied to clipboard",
      });
    }
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 max-w-7xl py-10">
          <div className="grid md:grid-cols-2 gap-8 animate-pulse">
            <div className="bg-slate-200 aspect-square rounded-md"></div>
            <div className="space-y-4">
              <div className="h-4 bg-slate-200 rounded w-1/4"></div>
              <div className="h-8 bg-slate-200 rounded w-3/4"></div>
              <div className="h-4 bg-slate-200 rounded w-1/3"></div>
              <div className="h-6 bg-slate-200 rounded w-1/4"></div>
              <div className="h-32 bg-slate-200 rounded"></div>
              <div className="h-10 bg-slate-200 rounded w-1/3"></div>
              <div className="h-10 bg-slate-200 rounded"></div>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }

  if (error || !product) {
    return (
      <MainLayout>
        <div className="container mx-auto px-4 max-w-7xl py-10">
          <div className="bg-white p-8 rounded-md shadow-sm text-center">
            <h1 className="text-2xl font-bold text-slate-900 mb-4">Product Not Found</h1>
            <p className="text-slate-600 mb-6">The product you're looking for doesn't exist or has been removed.</p>
            <Button asChild>
              <Link href="/products">Browse Products</Link>
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 max-w-7xl py-10">
        {/* Breadcrumbs */}
        <Breadcrumb className="mb-6">
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link href="/">Home</Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link href="/products">Products</Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link href={`/products?categoryId=${product.categoryId}`}>
                {product.category.name}
              </Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink className="font-medium text-slate-900">
              {product.name}
            </BreadcrumbLink>
          </BreadcrumbItem>
        </Breadcrumb>
        
        {/* Product Details */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Product Image */}
          <div className="bg-white rounded-md p-8 flex items-center justify-center">
            <img 
              src={product.imageUrl || DEFAULT_PRODUCT_IMAGE} 
              alt={product.name} 
              className="max-w-full max-h-[400px] object-contain"
            />
          </div>
          
          {/* Product Info */}
          <div>
            <div className="text-sm text-slate-500 uppercase mb-1">{product.category.name}</div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">{product.name}</h1>
            
            {/* Ratings */}
            <div className="flex items-center mb-4">
              <div className="flex text-amber-400 mr-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    className={`w-5 h-5 ${star <= Math.floor(Number(product.rating)) ? "fill-current" : "stroke-current fill-none"}`}
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.519 4.674c.3.921-.755 1.688-1.54 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.784.57-1.838-.197-1.539-1.118l1.519-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                    />
                  </svg>
                ))}
              </div>
              <span className="text-slate-600">{product.reviewCount} reviews</span>
            </div>
            
            {/* Price */}
            <div className="text-3xl font-bold text-primary mb-4">${Number(product.price).toFixed(2)}</div>
            
            {/* Description */}
            <p className="text-slate-700 mb-6">{product.description}</p>
            
            {/* Stock Status */}
            <div className="mb-4">
              <span className="font-medium">Availability: </span>
              {product.inventory > 0 ? (
                <span className="text-green-600">In Stock ({product.inventory} available)</span>
              ) : (
                <span className="text-red-600">Out of Stock</span>
              )}
            </div>
            
            {/* Quantity Selector */}
            <div className="mb-6">
              <label htmlFor="quantity" className="block font-medium text-slate-900 mb-2">Quantity</label>
              <div className="flex">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={decreaseQuantity}
                  disabled={quantity <= 1}
                  className="rounded-r-none"
                >
                  <MinusCircle className="h-4 w-4" />
                </Button>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  max={product.inventory}
                  value={quantity}
                  onChange={handleQuantityChange}
                  className="w-16 rounded-none text-center [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={increaseQuantity}
                  disabled={product.inventory <= quantity}
                  className="rounded-l-none"
                >
                  <PlusCircle className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <Button 
                size="lg" 
                className="flex-1"
                onClick={handleAddToCart}
                disabled={cartLoading || product.inventory === 0}
              >
                Add to Cart
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="flex-1"
              >
                <Heart className="mr-2 h-4 w-4" />
                Add to Wishlist
              </Button>
            </div>
            
            {/* Share */}
            <Button 
              variant="ghost" 
              className="mb-6"
              onClick={handleShare}
            >
              <Share2 className="mr-2 h-4 w-4" />
              Share This Product
            </Button>
            
            {/* Shipping Information */}
            <div className="border-t border-slate-200 pt-4 space-y-2">
              <div className="flex items-center text-sm text-slate-600">
                <Truck className="mr-2 h-4 w-4 text-primary" />
                <span>Free shipping on orders over $50</span>
              </div>
              <div className="flex items-center text-sm text-slate-600">
                <RotateCcw className="mr-2 h-4 w-4 text-primary" />
                <span>30-day return policy</span>
              </div>
              <div className="flex items-center text-sm text-slate-600">
                <ShieldCheck className="mr-2 h-4 w-4 text-primary" />
                <span>Secure payment</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Additional Information Tabs */}
        <div className="mb-12">
          <Tabs defaultValue="description">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Customer Reviews</TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="bg-white p-6 rounded-md mt-4">
              <div className="prose max-w-none">
                <p>{product.description}</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam auctor, nisl nec ultricies lacinia, nisl nisl aliquet nisl, nec ultricies nisl nisl nec nisl. Nullam auctor, nisl nec ultricies lacinia, nisl nisl aliquet nisl, nec ultricies nisl nisl nec nisl.</p>
                <ul>
                  <li>High-quality materials</li>
                  <li>Durable construction</li>
                  <li>Modern design</li>
                  <li>Versatile functionality</li>
                </ul>
              </div>
            </TabsContent>
            <TabsContent value="specifications" className="bg-white p-6 rounded-md mt-4">
              <div className="divide-y divide-slate-200">
                <div className="grid grid-cols-3 py-3">
                  <div className="font-medium text-slate-900">Brand</div>
                  <div className="col-span-2">ShopWave</div>
                </div>
                <div className="grid grid-cols-3 py-3">
                  <div className="font-medium text-slate-900">Model</div>
                  <div className="col-span-2">SWP-{product.id}</div>
                </div>
                <div className="grid grid-cols-3 py-3">
                  <div className="font-medium text-slate-900">Category</div>
                  <div className="col-span-2">{product.category.name}</div>
                </div>
                <div className="grid grid-cols-3 py-3">
                  <div className="font-medium text-slate-900">Weight</div>
                  <div className="col-span-2">0.5 kg</div>
                </div>
                <div className="grid grid-cols-3 py-3">
                  <div className="font-medium text-slate-900">Dimensions</div>
                  <div className="col-span-2">25 x 15 x 10 cm</div>
                </div>
                <div className="grid grid-cols-3 py-3">
                  <div className="font-medium text-slate-900">Warranty</div>
                  <div className="col-span-2">1 Year</div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="bg-white p-6 rounded-md mt-4">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Customer Reviews ({product.reviewCount})</h3>
                  <Button>Write a Review</Button>
                </div>
                
                <div className="border-t border-slate-200 pt-6">
                  <div className="space-y-6">
                    {[...Array(3)].map((_, index) => (
                      <div key={index} className="border-b border-slate-200 pb-6 last:border-0">
                        <div className="flex justify-between mb-2">
                          <div className="font-medium">John Doe</div>
                          <div className="text-slate-500 text-sm">{new Date().toLocaleDateString()}</div>
                        </div>
                        <div className="flex text-amber-400 mb-2">
                          {[...Array(5)].map((_, i) => (
                            <svg
                              key={i}
                              className={`w-4 h-4 ${i < 4 ? "fill-current" : "stroke-current fill-none"}`}
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.519 4.674c.3.921-.755 1.688-1.54 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.784.57-1.838-.197-1.539-1.118l1.519-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                              />
                            </svg>
                          ))}
                        </div>
                        <p className="text-slate-600">Great product! Exactly as described and arrived quickly. Would definitely buy again.</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        {/* Related Products */}
        <div>
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Related Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {relatedProducts
              .filter(p => p.id !== product.id)
              .slice(0, 4)
              .map((relatedProduct: ProductWithCategory) => (
                <div key={relatedProduct.id} className="bg-white rounded-md shadow-sm overflow-hidden">
                  <Link href={`/products/${relatedProduct.id}`}>
                    <a className="block">
                      <div className="aspect-square overflow-hidden">
                        <img 
                          src={relatedProduct.imageUrl || DEFAULT_PRODUCT_IMAGE} 
                          alt={relatedProduct.name} 
                          className="w-full h-full object-contain p-4 hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-medium text-slate-900 mb-1 line-clamp-1">{relatedProduct.name}</h3>
                        <div className="text-primary font-semibold">${Number(relatedProduct.price).toFixed(2)}</div>
                      </div>
                    </a>
                  </Link>
                </div>
              ))}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
