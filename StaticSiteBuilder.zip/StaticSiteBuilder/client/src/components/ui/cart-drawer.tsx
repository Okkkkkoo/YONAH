import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetFooter,
  SheetClose 
} from '@/components/ui/sheet';
import { XIcon, ShoppingCart, Plus, Minus, Trash2 } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/hooks/use-cart';
import { Link } from 'wouter';
import { DEFAULT_PRODUCT_IMAGE } from '@/lib/constants';

interface CartDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CartDrawer({ open, onOpenChange }: CartDrawerProps) {
  const { 
    items, 
    totalItems, 
    subtotal,
    shipping,
    total,
    updateItemQuantity,
    removeItem,
    isLoading 
  } = useCart();

  // Local state to handle quantity changes before submitting
  const [quantities, setQuantities] = useState<Record<number, number>>({});

  // Initialize quantities from cart items
  useEffect(() => {
    const newQuantities: Record<number, number> = {};
    items.forEach(item => {
      newQuantities[item.id] = item.quantity;
    });
    setQuantities(newQuantities);
  }, [items]);

  const handleQuantityChange = (id: number, value: number) => {
    setQuantities(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleQuantityUpdate = (id: number) => {
    const quantity = quantities[id];
    if (quantity > 0) {
      updateItemQuantity(id, quantity);
    }
  };

  const handleQuantityIncrement = (id: number) => {
    const newQuantity = (quantities[id] || 0) + 1;
    handleQuantityChange(id, newQuantity);
    updateItemQuantity(id, newQuantity);
  };

  const handleQuantityDecrement = (id: number) => {
    const currentQuantity = quantities[id] || 0;
    if (currentQuantity > 1) {
      const newQuantity = currentQuantity - 1;
      handleQuantityChange(id, newQuantity);
      updateItemQuantity(id, newQuantity);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="flex flex-col w-full sm:max-w-md">
        <SheetHeader className="px-1">
          <div className="flex justify-between items-center">
            <SheetTitle>Shopping Cart ({totalItems})</SheetTitle>
            <SheetClose className="rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2">
              <XIcon className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </SheetClose>
          </div>
        </SheetHeader>
        
        {/* Empty Cart State */}
        {items.length === 0 && (
          <div className="flex flex-col items-center justify-center flex-1 text-center py-10">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mb-4">
              <ShoppingCart className="h-8 w-8" />
            </div>
            <h3 className="text-slate-900 font-medium mb-1">Your cart is empty</h3>
            <p className="text-slate-600 mb-4">Looks like you haven't added any products yet.</p>
            <SheetClose asChild>
              <Button>Continue Shopping</Button>
            </SheetClose>
          </div>
        )}
        
        {/* Cart Items */}
        {items.length > 0 && (
          <>
            <div className="flex-1 overflow-y-auto py-2">
              {items.map((item) => (
                <div key={item.id} className="flex py-4 border-b border-slate-200">
                  {/* Product Image */}
                  <div className="w-20 h-20 bg-slate-100 rounded-md overflow-hidden mr-4 flex-shrink-0">
                    <img 
                      src={item.product.imageUrl || DEFAULT_PRODUCT_IMAGE} 
                      alt={item.product.name} 
                      className="w-full h-full object-contain"
                    />
                  </div>
                  
                  {/* Product Info */}
                  <div className="flex-1">
                    <Link 
                      href={`/products/${item.productId}`}
                      className="text-slate-900 font-medium line-clamp-2 hover:text-primary"
                    >
                      {item.product.name}
                    </Link>
                    <div className="text-primary font-semibold mt-1">
                      ${(Number(item.product.price) * item.quantity).toFixed(2)}
                    </div>
                    
                    {/* Quantity */}
                    <div className="flex items-center mt-2">
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8 rounded-l-md rounded-r-none"
                        onClick={() => handleQuantityDecrement(item.id)}
                        disabled={isLoading || quantities[item.id] <= 1}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <input
                        type="number"
                        min="1"
                        value={quantities[item.id] || item.quantity}
                        onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value) || 1)}
                        onBlur={() => handleQuantityUpdate(item.id)}
                        className="w-10 h-8 border-y border-slate-200 text-center focus:outline-none"
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        className="h-8 w-8 rounded-r-md rounded-l-none"
                        onClick={() => handleQuantityIncrement(item.id)}
                        disabled={isLoading}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                  
                  {/* Remove Button */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-slate-400 hover:text-red-500"
                    onClick={() => removeItem(item.id)}
                    disabled={isLoading}
                  >
                    <Trash2 className="h-4 w-4" />
                    <span className="sr-only">Remove</span>
                  </Button>
                </div>
              ))}
            </div>
            
            {/* Cart Summary */}
            <div className="mt-auto pt-4">
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Subtotal</span>
                  <span className="font-medium">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">Shipping</span>
                  <span className="font-medium">
                    {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between font-medium">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="mt-6 space-y-3">
                <SheetClose asChild>
                  <Button asChild className="w-full">
                    <Link href="/checkout">Proceed to Checkout</Link>
                  </Button>
                </SheetClose>
                <SheetClose asChild>
                  <Button variant="outline" className="w-full">
                    Continue Shopping
                  </Button>
                </SheetClose>
              </div>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
