import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { XIcon } from 'lucide-react';
import { CATEGORIES, PRICE_RANGE, RATING_OPTIONS } from '@/lib/constants';
import { cn } from '@/lib/utils';

interface FilterSidebarProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  activeCategory: string;
  onCategoryChange: (category: string) => void;
  filters: {
    price: [number, number];
    rating: number;
    inStock: boolean;
  };
  onFilterChange: (name: string, value: any) => void;
  onApplyFilters: () => void;
  onClearFilters: () => void;
  className?: string;
}

export function FilterSidebar({
  open,
  onOpenChange,
  activeCategory,
  onCategoryChange,
  filters,
  onFilterChange,
  onApplyFilters,
  onClearFilters,
  className
}: FilterSidebarProps) {
  const [localPrice, setLocalPrice] = useState<[number, number]>(filters.price);
  
  const handlePriceChange = (value: number[]) => {
    setLocalPrice([value[0], value[1]]);
  };
  
  const applyPriceFilter = () => {
    onFilterChange('price', localPrice);
  };

  return (
    <div 
      className={cn(
        "bg-white p-4 rounded-md shadow-sm overflow-auto",
        className,
        open ? "block" : "hidden lg:block"
      )}
    >
      <div className="flex justify-between items-center mb-4 lg:hidden">
        <h3 className="font-medium text-slate-900">Filters</h3>
        <Button 
          variant="ghost" 
          size="icon" 
          className="text-slate-500 hover:text-slate-700"
          onClick={() => onOpenChange(false)}
        >
          <XIcon className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </Button>
      </div>
      
      {/* Price Range Filter */}
      <div className="mb-6">
        <h4 className="font-medium text-slate-900 mb-3">Price Range</h4>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-600">${localPrice[0]}</span>
            <span className="text-sm text-slate-600">${localPrice[1]}</span>
          </div>
          <Slider
            value={[localPrice[0], localPrice[1]]}
            min={PRICE_RANGE.MIN}
            max={PRICE_RANGE.MAX}
            step={PRICE_RANGE.STEP}
            onValueChange={handlePriceChange}
            onValueCommit={applyPriceFilter}
            className="mt-2"
          />
        </div>
      </div>
      
      {/* Categories Filter */}
      <div className="mb-6">
        <h4 className="font-medium text-slate-900 mb-3">Categories</h4>
        <div className="space-y-2">
          {CATEGORIES.map((category) => (
            <div key={category.id} className="flex items-center space-x-2">
              <Checkbox 
                id={`category-${category.id}`}
                checked={activeCategory === category.id || activeCategory === 'all'}
                onCheckedChange={() => onCategoryChange(category.id)}
              />
              <Label 
                htmlFor={`category-${category.id}`}
                className="text-sm cursor-pointer"
              >
                {category.name}
              </Label>
            </div>
          ))}
        </div>
      </div>
      
      {/* Ratings Filter */}
      <div className="mb-6">
        <h4 className="font-medium text-slate-900 mb-3">Ratings</h4>
        <RadioGroup 
          value={filters.rating.toString()}
          onValueChange={(value) => onFilterChange('rating', parseInt(value))}
        >
          {RATING_OPTIONS.map((option) => (
            <div key={option.value} className="flex items-center space-x-2">
              <RadioGroupItem value={option.value.toString()} id={`rating-${option.value}`} />
              <Label htmlFor={`rating-${option.value}`} className="flex items-center cursor-pointer">
                <div className="flex text-amber-400 mr-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg
                      key={star}
                      className={`h-4 w-4 ${star <= option.value ? "fill-current" : "stroke-current fill-none"}`}
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.519 4.674c.3.921-.755 1.688-1.54 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.784.57-1.838-.197-1.539-1.118l1.519-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                      />
                    </svg>
                  ))}
                </div>
                <span className="text-sm text-slate-600 ml-1">& up</span>
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>
      
      {/* Availability Filter */}
      <div className="mb-6">
        <h4 className="font-medium text-slate-900 mb-3">Availability</h4>
        <div className="flex items-center space-x-2">
          <Checkbox 
            id="availability"
            checked={filters.inStock}
            onCheckedChange={(checked) => onFilterChange('inStock', checked === true)}
          />
          <Label htmlFor="availability" className="text-sm cursor-pointer">
            In Stock Only
          </Label>
        </div>
      </div>
      
      {/* Apply/Clear Filters buttons */}
      <div className="flex space-x-2">
        <Button 
          className="flex-1" 
          onClick={onApplyFilters}
        >
          Apply
        </Button>
        <Button 
          variant="outline" 
          className="flex-1"
          onClick={onClearFilters}
        >
          Clear
        </Button>
      </div>
    </div>
  );
}
