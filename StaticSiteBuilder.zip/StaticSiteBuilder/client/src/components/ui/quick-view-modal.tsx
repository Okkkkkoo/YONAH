import { 
  Dialog, 
  DialogContent, 
  DialogClose 
} from '@/components/ui/dialog';
import { ProductWithCategory } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { XIcon, Heart, ShoppingCart, Truck, RotateCcw, ShieldCheck } from 'lucide-react';
import { Link } from 'wouter';
import { useCart } from '@/hooks/use-cart';
import { DEFAULT_PRODUCT_IMAGE } from '@/lib/constants';

interface QuickViewModalProps {
  product: ProductWithCategory | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function QuickViewModal({ product, open, onOpenChange }: QuickViewModalProps) {
  const [quantity, setQuantity] = useState(1);
  const { addItem, isLoading } = useCart();

  if (!product) return null;

  const handleAddToCart = () => {
    addItem(product.id, quantity);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl p-0 overflow-hidden">
        <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 z-10">
          <XIcon className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </DialogClose>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Product Image */}
          <div className="relative aspect-square bg-slate-100 flex items-center justify-center p-8">
            <img 
              src={product.imageUrl || DEFAULT_PRODUCT_IMAGE} 
              alt={product.name} 
              className="max-h-full max-w-full object-contain"
            />
          </div>
          
          {/* Product Info */}
          <div className="p-6">
            <div className="text-xs text-slate-500 uppercase mb-1">{product.category.name}</div>
            <h2 className="text-xl font-bold text-slate-900 mb-2">{product.name}</h2>
            
            {/* Ratings */}
            <div className="flex items-center mb-3">
              <div className="flex text-amber-400 mr-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    className={`h-4 w-4 ${star <= Math.floor(Number(product.rating)) ? "fill-current" : "stroke-current fill-none"}`}
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.519 4.674c.3.921-.755 1.688-1.54 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.784.57-1.838-.197-1.539-1.118l1.519-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                    />
                  </svg>
                ))}
              </div>
              <span className="text-sm text-slate-500">({product.reviewCount} reviews)</span>
            </div>
            
            {/* Price */}
            <div className="text-2xl font-bold text-primary mb-3">${Number(product.price).toFixed(2)}</div>
            
            {/* Description */}
            <div className="text-slate-700 mb-6">{product.description}</div>
            
            {/* Stock Status */}
            <div className="mb-4 text-sm">
              <span className="font-medium">Availability: </span>
              {product.inventory > 0 ? (
                <span className="text-green-600">In Stock ({product.inventory} available)</span>
              ) : (
                <span className="text-red-600">Out of Stock</span>
              )}
            </div>
            
            {/* Quantity */}
            <div className="mb-4">
              <label className="block text-slate-700 font-medium mb-2">Quantity</label>
              <div className="flex items-center">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-10 w-10 rounded-l-md rounded-r-none"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                >
                  <span>-</span>
                </Button>
                <Input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  min="1"
                  className="h-10 w-16 rounded-none text-center [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                />
                <Button
                  variant="outline"
                  size="icon"
                  className="h-10 w-10 rounded-r-md rounded-l-none"
                  onClick={() => setQuantity(quantity + 1)}
                >
                  <span>+</span>
                </Button>
              </div>
            </div>
            
            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button 
                className="flex-1"
                onClick={handleAddToCart}
                disabled={isLoading || product.inventory === 0}
              >
                <ShoppingCart className="mr-2 h-4 w-4" />
                Add to Cart
              </Button>
              <Button variant="outline" className="flex-1">
                <Heart className="mr-2 h-4 w-4" />
                Add to Wishlist
              </Button>
            </div>
            
            {/* Additional Info */}
            <div className="mt-6 pt-4 border-t border-slate-200">
              <div className="flex items-center text-sm text-slate-600 mb-2">
                <Truck className="h-4 w-4 mr-2" />
                <span>Free shipping on orders over $50</span>
              </div>
              <div className="flex items-center text-sm text-slate-600 mb-2">
                <RotateCcw className="h-4 w-4 mr-2" />
                <span>30-day return policy</span>
              </div>
              <div className="flex items-center text-sm text-slate-600">
                <ShieldCheck className="h-4 w-4 mr-2" />
                <span>Secure payment</span>
              </div>
            </div>
            
            {/* View Full Details */}
            <div className="mt-4 pt-4 border-t border-slate-200">
              <DialogClose asChild>
                <Button variant="link" asChild>
                  <Link href={`/products/${product.id}`}>
                    View full product details
                  </Link>
                </Button>
              </DialogClose>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
