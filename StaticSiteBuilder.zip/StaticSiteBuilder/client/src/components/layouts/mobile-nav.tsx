import { Link } from 'wouter';
import { useCart } from '@/hooks/use-cart';
import { useState } from 'react';
import { CartDrawer } from '@/components/ui/cart-drawer';
import { Home, Search, Heart, ShoppingCart } from 'lucide-react';

export function MobileNav() {
  const { totalItems } = useCart();
  const [cartOpen, setCartOpen] = useState(false);

  return (
    <>
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.1)] z-30">
        <div className="grid grid-cols-4 py-2">
          <Link href="/">
            <a className="flex flex-col items-center text-slate-600 hover:text-primary">
              <Home className="h-5 w-5" />
              <span className="text-xs mt-1">Home</span>
            </a>
          </Link>
          <Link href="/products">
            <a className="flex flex-col items-center text-slate-600 hover:text-primary">
              <Search className="h-5 w-5" />
              <span className="text-xs mt-1">Search</span>
            </a>
          </Link>
          <Link href="/account/wishlist">
            <a className="flex flex-col items-center text-slate-600 hover:text-primary">
              <Heart className="h-5 w-5" />
              <span className="text-xs mt-1">Wishlist</span>
            </a>
          </Link>
          <button 
            className="flex flex-col items-center text-slate-600 hover:text-primary relative"
            onClick={() => setCartOpen(true)}
          >
            <ShoppingCart className="h-5 w-5" />
            {totalItems > 0 && (
              <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                {totalItems}
              </span>
            )}
            <span className="text-xs mt-1">Cart</span>
          </button>
        </div>
      </div>
      
      <CartDrawer open={cartOpen} onOpenChange={setCartOpen} />
    </>
  );
}
