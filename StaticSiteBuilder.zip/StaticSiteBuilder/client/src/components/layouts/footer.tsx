import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Send 
} from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

export function Footer() {
  const [email, setEmail] = useState('');
  const { toast } = useToast();
  
  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would send a request to subscribe the email
    toast({
      title: "Success!",
      description: "You have been subscribed to our newsletter.",
    });
    setEmail('');
  };

  return (
    <footer className="bg-slate-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Shop<span className="text-orange-500">Wave</span></h3>
            <p className="text-slate-400 mb-4">Your one-stop shop for quality products at affordable prices.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Facebook size={18} />
                <span className="sr-only">Facebook</span>
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Twitter size={18} />
                <span className="sr-only">Twitter</span>
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Instagram size={18} />
                <span className="sr-only">Instagram</span>
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Linkedin size={18} />
                <span className="sr-only">Pinterest</span>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Shop</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/products?featured=true">
                  <a className="text-slate-400 hover:text-white transition-colors">New Arrivals</a>
                </Link>
              </li>
              <li>
                <Link href="/products?sort=featured">
                  <a className="text-slate-400 hover:text-white transition-colors">Best Sellers</a>
                </Link>
              </li>
              <li>
                <Link href="/products?sale=true">
                  <a className="text-slate-400 hover:text-white transition-colors">Sale</a>
                </Link>
              </li>
              <li>
                <Link href="/products">
                  <a className="text-slate-400 hover:text-white transition-colors">All Products</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Customer Service</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/contact">
                  <a className="text-slate-400 hover:text-white transition-colors">Contact Us</a>
                </Link>
              </li>
              <li>
                <Link href="/track-order">
                  <a className="text-slate-400 hover:text-white transition-colors">Track Your Order</a>
                </Link>
              </li>
              <li>
                <Link href="/returns">
                  <a className="text-slate-400 hover:text-white transition-colors">Returns & Exchanges</a>
                </Link>
              </li>
              <li>
                <Link href="/shipping">
                  <a className="text-slate-400 hover:text-white transition-colors">Shipping Policy</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Stay Updated</h4>
            <p className="text-slate-400 mb-4">Subscribe to our newsletter for updates and exclusive offers.</p>
            <form onSubmit={handleSubscribe} className="flex">
              <Input 
                type="email" 
                placeholder="Your email address" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 rounded-r-none bg-slate-800 border-slate-700 focus-visible:ring-primary focus-visible:ring-offset-slate-900"
              />
              <Button type="submit" size="icon" className="rounded-l-none">
                <Send className="h-4 w-4" />
                <span className="sr-only">Subscribe</span>
              </Button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-slate-800 pt-6 flex flex-col md:flex-row justify-between items-center">
          <div className="text-slate-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} ShopWave. All rights reserved.
          </div>
          
          <div className="flex flex-wrap justify-center space-x-4">
            <Link href="/privacy">
              <a className="text-slate-400 hover:text-white transition-colors text-sm">Privacy Policy</a>
            </Link>
            <Link href="/terms">
              <a className="text-slate-400 hover:text-white transition-colors text-sm">Terms of Service</a>
            </Link>
            <Link href="/cookies">
              <a className="text-slate-400 hover:text-white transition-colors text-sm">Cookie Policy</a>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
