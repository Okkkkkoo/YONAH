import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { CartDrawer } from '@/components/ui/cart-drawer';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { CATEGORIES } from '@/lib/constants';
import { useCart } from '@/hooks/use-cart';
import { useAuth } from '@/hooks/useAuth';
import { 
  Search, 
  User, 
  ShoppingCart, 
  Menu,
  LogIn,
  UserPlus,
  UserCircle,
  ClipboardList,
  Heart,
  LogOut,
  LayoutDashboard
} from 'lucide-react';

export function Navbar() {
  const [location] = useLocation();
  const [searchOpen, setSearchOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Get authentication state from our auth hook
  const { user, isAuthenticated, isAdmin } = useAuth();

  const { totalItems } = useCart();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Redirect to products page with search query
    window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`;
    setSearchOpen(false);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-30">
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Top Navigation */}
        <div className="flex items-center justify-between py-4">
          {/* Logo and Main Navigation */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-2xl font-bold text-primary">Yona</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden ml-10 md:flex space-x-8">
              <Link href="/">
                <a className={`${location === '/' ? 'text-slate-800 font-medium' : 'text-slate-600'} hover:text-primary`}>
                  Home
                </a>
              </Link>
              <Link href="/products">
                <a className={`${location === '/products' ? 'text-slate-800 font-medium' : 'text-slate-600'} hover:text-primary`}>
                  Shop
                </a>
              </Link>
              <Link href="/products?featured=true">
                <a className={`${location.includes('featured=true') ? 'text-slate-800 font-medium' : 'text-slate-600'} hover:text-primary`}>
                  New Arrivals
                </a>
              </Link>
              <Link href="/contact">
                <a className={`${location === '/contact' ? 'text-slate-800 font-medium' : 'text-slate-600'} hover:text-primary`}>
                  Contact
                </a>
              </Link>
            </nav>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            {/* Search */}
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                aria-label="Search"
                className="text-slate-700 hover:text-primary"
                onClick={() => setSearchOpen(!searchOpen)}
              >
                <Search className="h-5 w-5" />
              </Button>

              {/* Search Dropdown */}
              {searchOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-md shadow-lg p-4 z-50">
                  <form onSubmit={handleSearch} className="flex items-center border border-slate-200 rounded-md overflow-hidden">
                    <Input
                      type="text"
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="border-0 focus-visible:ring-0"
                    />
                    <Button type="submit" size="sm" className="rounded-l-none">
                      <Search className="h-4 w-4" />
                    </Button>
                  </form>
                  <div className="mt-2">
                    <div className="text-xs uppercase text-slate-500 font-medium mb-1">Suggested</div>
                    <Link href="/products?search=headphones">
                      <a className="block py-1 text-slate-700 hover:text-primary">
                        Wireless Headphones
                      </a>
                    </Link>
                    <Link href="/products?search=watch">
                      <a className="block py-1 text-slate-700 hover:text-primary">
                        Smart Watches
                      </a>
                    </Link>
                    <Link href="/products?search=shoes">
                      <a className="block py-1 text-slate-700 hover:text-primary">
                        Running Shoes
                      </a>
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {/* User Account */}
            <div className="relative">
              <DropdownMenu open={userMenuOpen} onOpenChange={setUserMenuOpen}>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="User account"
                    className="text-slate-700 hover:text-primary"
                  >
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {!isAuthenticated ? (
                    <>
                      <DropdownMenuItem asChild>
                        <Link href="/login">
                          <a className="flex items-center cursor-pointer w-full">
                            <LogIn className="mr-2 h-4 w-4" />
                            <span>Sign In</span>
                          </a>
                        </Link>
                      </DropdownMenuItem>
                    </>
                  ) : (
                    <>
                      <DropdownMenuItem asChild>
                        <Link href="/account/profile">
                          <a className="flex items-center cursor-pointer w-full">
                            <UserCircle className="mr-2 h-4 w-4" />
                            <span>My Account</span>
                          </a>
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/account/orders">
                          <a className="flex items-center cursor-pointer w-full">
                            <ClipboardList className="mr-2 h-4 w-4" />
                            <span>My Orders</span>
                          </a>
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/account/wishlist">
                          <a className="flex items-center cursor-pointer w-full">
                            <Heart className="mr-2 h-4 w-4" />
                            <span>Wishlist</span>
                          </a>
                        </Link>
                      </DropdownMenuItem>
                      {isAdmin && (
                        <DropdownMenuItem asChild>
                          <Link href="/admin">
                            <a className="flex items-center cursor-pointer w-full">
                              <LayoutDashboard className="mr-2 h-4 w-4" />
                              <span>Admin Dashboard</span>
                            </a>
                          </Link>
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem>
                        <a 
                          href="/api/logout" 
                          className="flex items-center cursor-pointer w-full"
                          onClick={(e) => {
                            e.preventDefault();
                            window.location.href = '/api/logout';
                          }}
                        >
                          <LogOut className="mr-2 h-4 w-4" />
                          <span>Sign Out</span>
                        </a>
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Shopping Cart */}
            <Button
              variant="ghost"
              size="icon"
              aria-label="Shopping cart"
              className="text-slate-700 hover:text-primary relative"
              onClick={() => setCartOpen(true)}
            >
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                  {totalItems}
                </span>
              )}
            </Button>

            {/* Mobile Menu Button */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Menu"
                  className="text-slate-700 hover:text-primary md:hidden"
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[400px]">
                <div className="py-4 flex flex-col h-full">
                  <Link href="/" className="flex items-center mb-6">
                    <span className="text-2xl font-bold text-primary">Yona</span>
                  </Link>

                  <nav className="flex flex-col space-y-4 mb-6">
                    <Link href="/">
                      <a className={`${location === '/' ? 'text-primary font-medium' : 'text-slate-800'} hover:text-primary py-2 border-b border-slate-100`}>
                        Home
                      </a>
                    </Link>
                    <Link href="/products">
                      <a className={`${location === '/products' ? 'text-primary font-medium' : 'text-slate-800'} hover:text-primary py-2 border-b border-slate-100`}>
                        Shop
                      </a>
                    </Link>
                    <Link href="/products?featured=true">
                      <a className={`${location.includes('featured=true') ? 'text-primary font-medium' : 'text-slate-800'} hover:text-primary py-2 border-b border-slate-100`}>
                        New Arrivals
                      </a>
                    </Link>
                    <Link href="/contact">
                      <a className={`${location === '/contact' ? 'text-primary font-medium' : 'text-slate-800'} hover:text-primary py-2 border-b border-slate-100`}>
                        Contact
                      </a>
                    </Link>
                  </nav>

                  <div className="mt-auto">
                    {!isAuthenticated ? (
                      <div className="flex flex-col space-y-2">
                        <Button asChild>
                          <Link href="/login">
                            Sign In
                          </Link>
                        </Button>
                      </div>
                    ) : (
                      <div className="flex flex-col space-y-2">
                        <Link href="/account/profile">
                          <a className="flex items-center text-slate-800 hover:text-primary py-2">
                            <UserCircle className="mr-2 h-4 w-4" />
                            <span>My Account</span>
                          </a>
                        </Link>
                        <Link href="/account/orders">
                          <a className="flex items-center text-slate-800 hover:text-primary py-2">
                            <ClipboardList className="mr-2 h-4 w-4" />
                            <span>My Orders</span>
                          </a>
                        </Link>
                        {isAdmin && (
                          <Link href="/admin">
                            <a className="flex items-center text-slate-800 hover:text-primary py-2">
                              <LayoutDashboard className="mr-2 h-4 w-4" />
                              <span>Admin Dashboard</span>
                            </a>
                          </Link>
                        )}
                        <Button 
                          variant="outline" 
                          className="w-full justify-start"
                          onClick={() => window.location.href = '/api/logout'}
                        >
                          <LogOut className="mr-2 h-4 w-4" />
                          <span>Sign Out</span>
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Category Navigation */}
        <div className="overflow-x-auto scroll-hidden">
          <nav className="flex space-x-6 py-2 border-t border-slate-200 text-sm whitespace-nowrap">
            {CATEGORIES.map((category) => (
              <Link key={category.id} href={category.id === 'all' ? '/products' : `/products?category=${category.id}`}>
                <a className={`${location.includes(`category=${category.id}`) || (category.id === 'all' && location === '/products') ? 'text-primary font-medium' : 'text-slate-600 hover:text-slate-900'}`}>
                  {category.name}
                </a>
              </Link>
            ))}
          </nav>
        </div>
      </div>

      {/* Cart Drawer */}
      <CartDrawer open={cartOpen} onOpenChange={setCartOpen} />
    </header>
  );
}