import { ReactNode, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

interface ProtectedRouteProps {
  children: ReactNode;
  requireAdmin?: boolean;
}

export function ProtectedRoute({ children, requireAdmin = false }: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  const isAuthenticated = !!user;
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    // Only redirect after we've confirmed the user isn't authenticated
    // This prevents flash of content before redirect
    if (!isLoading && !isAuthenticated) {
      // Redirect to the login page
      setLocation(`/login?returnTo=${encodeURIComponent(window.location.pathname)}`);
    }
    
    // If admin route but user is not admin, redirect to home
    if (!isLoading && isAuthenticated && requireAdmin && !isAdmin) {
      setLocation("/");
    }
  }, [isLoading, isAuthenticated, isAdmin, requireAdmin, setLocation]);

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Show unauthorized message while redirecting (for admin routes)
  if (!isLoading && isAuthenticated && requireAdmin && !isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-2">Unauthorized</h2>
          <p className="text-muted-foreground mb-4">You don't have permission to access this page.</p>
          <p>Redirecting to home...</p>
        </div>
      </div>
    );
  }

  // If authenticated and passes admin check if required, render the content
  if (isAuthenticated && (!requireAdmin || isAdmin)) {
    return <>{children}</>;
  }

  // Show loading message while redirecting to login
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <h2 className="text-2xl font-semibold mb-2">Authentication Required</h2>
        <p className="text-muted-foreground mb-4">Please log in to access this page.</p>
        <p>Redirecting to login...</p>
      </div>
    </div>
  );
}