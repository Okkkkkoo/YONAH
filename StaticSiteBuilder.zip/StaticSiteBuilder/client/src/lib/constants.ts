// This file contains constants used throughout the application

// Category data for women's fashion store
export const CATEGORIES = [
  { id: 'all', name: 'All Products' },
  { id: 'dresses', name: 'Dresses' },
  { id: 'tops', name: 'Tops & Blouses' },
  { id: 'pants', name: 'Pants & Jeans' },
  { id: 'skirts', name: 'Skirts' },
  { id: 'outerwear', name: 'Outerwear' },
  { id: 'activewear', name: 'Activewear' },
  { id: 'shoes', name: 'Shoes' },
  { id: 'accessories', name: 'Accessories' },
  { id: 'sale', name: 'Sale' }
];

// Category images for featured sections - women's fashion
export const CATEGORY_IMAGES = {
  dresses: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&q=80',
  tops: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=600&q=80',
  pants: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=600&q=80',
  skirts: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=600&q=80',
  outerwear: 'https://images.unsplash.com/photo-1548624313-0396c75e4b579?w=600&q=80',
  activewear: 'https://images.unsplash.com/photo-1483721310020-03333e577078?w=600&q=80',
  shoes: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&q=80',
  accessories: 'https://images.unsplash.com/photo-1589782182703-2aaa69037b5b?w=600&q=80',
  sale: 'https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=600&q=80',
  all: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&q=80'
};

// Checkout steps
export const CHECKOUT_STEPS = [
  { id: 'cart', name: 'Cart' },
  { id: 'shipping', name: 'Shipping' },
  { id: 'payment', name: 'Payment' },
  { id: 'confirmation', name: 'Confirmation' }
];

// Order status options
export const ORDER_STATUS = {
  PENDING: 'pending',
  PROCESSING: 'processing',
  SHIPPED: 'shipped',
  DELIVERED: 'delivered',
  CANCELLED: 'cancelled'
};

// Pagination defaults
export const DEFAULT_PAGE_SIZE = 12;

// Price range for filters
export const PRICE_RANGE = {
  MIN: 0,
  MAX: 1000,
  STEP: 50
};

// Rating options for filters
export const RATING_OPTIONS = [
  { value: 4, label: '4 & up' },
  { value: 3, label: '3 & up' },
  { value: 2, label: '2 & up' },
  { value: 1, label: '1 & up' }
];

// Sort options
export const SORT_OPTIONS = [
  { value: 'featured', label: 'Featured' },
  { value: 'price_asc', label: 'Price: Low to High' },
  { value: 'price_desc', label: 'Price: High to Low' },
  { value: 'newest', label: 'Newest' },
  { value: 'rating', label: 'Best Rated' }
];

// Company features
export const COMPANY_FEATURES = [
  {
    icon: 'Truck',
    title: 'Free Shipping',
    description: 'On orders over $50'
  },
  {
    icon: 'RotateCcw',
    title: 'Easy Returns',
    description: '30-day return policy'
  },
  {
    icon: 'ShieldCheck',
    title: 'Secure Payments',
    description: 'Protected by encryption'
  },
  {
    icon: 'Headphones',
    title: '24/7 Support',
    description: 'Help when you need it'
  }
];

// Admin menu items
export const ADMIN_MENU_ITEMS = [
  { 
    id: 'dashboard', 
    label: 'Dashboard', 
    icon: 'LayoutDashboard',
    path: '/admin'
  },
  { 
    id: 'products', 
    label: 'Products', 
    icon: 'ShoppingBag',
    path: '/admin/products'
  },
  { 
    id: 'categories', 
    label: 'Categories', 
    icon: 'Folder',
    path: '/admin/categories'
  },
  { 
    id: 'orders', 
    label: 'Orders', 
    icon: 'ClipboardList',
    path: '/admin/orders'
  },
  { 
    id: 'customers', 
    label: 'Customers', 
    icon: 'Users',
    path: '/admin/customers'
  },
  { 
    id: 'shipments', 
    label: 'Shipments', 
    icon: 'Truck',
    path: '/admin/shipments'
  },
  { 
    id: 'reports', 
    label: 'Reports', 
    icon: 'BarChart3',
    path: '/admin/reports'
  },
  { 
    id: 'discounts', 
    label: 'Discounts', 
    icon: 'Tag',
    path: '/admin/discounts' 
  },
  { 
    id: 'ads', 
    label: 'Advertisements', 
    icon: 'Image',
    path: '/admin/ads'
  },
  { 
    id: 'settings', 
    label: 'Settings', 
    icon: 'Settings',
    path: '/admin/settings'
  }
];

// Product placeholders and defaults
export const DEFAULT_PRODUCT_IMAGE = 'https://placehold.co/400x400/e2e8f0/1e293b?text=Product+Image';
