import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Product } from '@shared/schema';
import { queryClient } from '@/lib/queryClient';

type CartItemType = {
  id: number;
  productId: number;
  quantity: number;
  product: Product;
};

type CartContextType = {
  items: CartItemType[];
  totalItems: number;
  subtotal: number;
  shipping: number;
  total: number;
  addItem: (productId: number, quantity?: number) => Promise<void>;
  updateItemQuantity: (id: number, quantity: number) => Promise<void>;
  removeItem: (id: number) => Promise<void>;
  clearCart: () => Promise<void>;
  isLoading: boolean;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

// Mock user ID for storing cart (in a real app, would come from authentication)
const USER_ID = 1;

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItemType[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Calculate totals
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = items.reduce((sum, item) => sum + (Number(item.product.price) * item.quantity), 0);
  
  // Fixed shipping cost for simplicity
  const shipping = subtotal > 50 ? 0 : 5.99;
  const total = subtotal + shipping;

  // Load cart items on mount
  useEffect(() => {
    const loadCart = async () => {
      try {
        setIsLoading(true);
        const response = await fetch(`/api/cart/${USER_ID}`);
        
        if (!response.ok) {
          // Instead of throwing an error, create an empty cart for first-time users
          if (response.status === 404 || response.status === 500) {
            setItems([]);
            return;
          }
          throw new Error('Failed to load cart');
        }
        
        const data = await response.json();
        setItems(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error("Cart error:", error);
        // Start with an empty cart instead of showing an error
        setItems([]);
      } finally {
        setIsLoading(false);
      }
    };

    loadCart();
  }, [toast]);

  // Add item to cart
  const addItem = async (productId: number, quantity = 1) => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest('POST', '/api/cart', {
        userId: USER_ID,
        productId,
        quantity
      });
      
      if (!response.ok) {
        throw new Error('Failed to add item to cart');
      }
      
      // Invalidate cart query to refetch data
      queryClient.invalidateQueries({ queryKey: [`/api/cart/${USER_ID}`] });
      
      // Update local state without waiting for refetch
      const existingItem = items.find(item => item.productId === productId);
      
      if (existingItem) {
        setItems(items.map(item => 
          item.productId === productId 
          ? { ...item, quantity: item.quantity + quantity } 
          : item
        ));
      } else {
        // Fetch the product details for the new item
        const productResponse = await fetch(`/api/products/${productId}`);
        if (!productResponse.ok) {
          throw new Error('Failed to get product details');
        }
        
        const product = await productResponse.json();
        const cartItemResponse = await response.json();
        
        setItems([...items, { 
          ...cartItemResponse, 
          product 
        }]);
      }
      
      toast({
        title: 'Item added',
        description: 'The item has been added to your cart.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add item to cart. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Update item quantity
  const updateItemQuantity = async (id: number, quantity: number) => {
    if (quantity < 1) {
      return removeItem(id);
    }
    
    try {
      setIsLoading(true);
      
      const response = await apiRequest('PUT', `/api/cart/${id}`, { quantity });
      
      if (!response.ok) {
        throw new Error('Failed to update cart item');
      }
      
      // Update local state without waiting for refetch
      setItems(items.map(item => 
        item.id === id ? { ...item, quantity } : item
      ));
      
      // Invalidate cart query to refetch data
      queryClient.invalidateQueries({ queryKey: [`/api/cart/${USER_ID}`] });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update item quantity. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Remove item from cart
  const removeItem = async (id: number) => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest('DELETE', `/api/cart/${id}`);
      
      if (!response.ok) {
        throw new Error('Failed to remove item from cart');
      }
      
      // Update local state without waiting for refetch
      setItems(items.filter(item => item.id !== id));
      
      // Invalidate cart query to refetch data
      queryClient.invalidateQueries({ queryKey: [`/api/cart/${USER_ID}`] });
      
      toast({
        title: 'Item removed',
        description: 'The item has been removed from your cart.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to remove item from cart. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Clear cart
  const clearCart = async () => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest('DELETE', `/api/cart/user/${USER_ID}`);
      
      if (!response.ok) {
        throw new Error('Failed to clear cart');
      }
      
      // Update local state
      setItems([]);
      
      // Invalidate cart query to refetch data
      queryClient.invalidateQueries({ queryKey: [`/api/cart/${USER_ID}`] });
      
      toast({
        title: 'Cart cleared',
        description: 'Your cart has been cleared.',
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to clear cart. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <CartContext.Provider value={{
      items,
      totalItems,
      subtotal,
      shipping,
      total,
      addItem,
      updateItemQuantity,
      removeItem,
      clearCart,
      isLoading
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  
  return context;
}
