import { storage } from "./storage";

// Function to seed initial data for the StyleHub e-commerce platform
export async function seedInitialData() {
  console.log("Seeding initial data for StyleHub store...");
  
  // Create categories
  const categories = [
    {
      name: "Clothing",
      description: "Stylish clothing for all occasions",
      image: "https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?w=800&auto=format&fit=crop",
      slug: "clothing",
      featured: true,
      displayOrder: 1
    },
    {
      name: "Accessories",
      description: "Complete your look with our accessories",
      image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop",
      slug: "accessories",
      featured: true,
      displayOrder: 2
    },
    {
      name: "Footwear",
      description: "Comfortable and trendy footwear options",
      image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=800&auto=format&fit=crop",
      slug: "footwear",
      featured: true,
      displayOrder: 3
    },
    {
      name: "Home",
      description: "Stylish items for your home",
      image: "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w=800&auto=format&fit=crop",
      slug: "home",
      featured: false,
      displayOrder: 4
    }
  ];
  
  const createdCategories = [];
  for (const category of categories) {
    try {
      const existingCategory = await storage.getCategoryByName(category.name);
      if (!existingCategory) {
        const created = await storage.createCategory(category);
        createdCategories.push(created);
        console.log(`Created category: ${category.name}`);
      } else {
        createdCategories.push(existingCategory);
        console.log(`Category already exists: ${category.name}`);
      }
    } catch (error) {
      console.error(`Error creating category ${category.name}:`, error);
    }
  }
  
  // Create products
  const products = [
    {
      name: "Classic White T-Shirt",
      description: "A comfortable cotton t-shirt for everyday wear",
      price: "24.99",
      imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&auto=format&fit=crop",
      inventory: 100,
      categoryId: createdCategories.find(c => c.slug === "clothing")?.id || 1,
      sku: "TS-CW-001",
      slug: "classic-white-tshirt",
      brand: "StyleHub",
      colors: ["white", "black", "gray"],
      sizes: ["S", "M", "L", "XL"],
      materials: ["100% Cotton"],
      tags: ["t-shirt", "basic", "essential"],
      rating: "4.8",
      reviewCount: 24,
      featured: true,
      isNew: true
    },
    {
      name: "Slim Fit Jeans",
      description: "Modern slim fit jeans with stretch for comfort",
      price: "59.99",
      imageUrl: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=800&auto=format&fit=crop",
      inventory: 75,
      categoryId: createdCategories.find(c => c.slug === "clothing")?.id || 1,
      sku: "JN-SF-002",
      slug: "slim-fit-jeans",
      brand: "DenimCo",
      colors: ["blue", "black", "gray"],
      sizes: ["28", "30", "32", "34", "36"],
      materials: ["98% Cotton", "2% Elastane"],
      tags: ["jeans", "denim", "slim fit"],
      rating: "4.5",
      reviewCount: 18,
      featured: true
    },
    {
      name: "Leather Crossbody Bag",
      description: "Stylish leather crossbody bag with multiple compartments",
      price: "89.99",
      imageUrl: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&auto=format&fit=crop",
      inventory: 30,
      categoryId: createdCategories.find(c => c.slug === "accessories")?.id || 2,
      sku: "BG-LC-003",
      slug: "leather-crossbody-bag",
      brand: "LuxeLeather",
      colors: ["brown", "black", "tan"],
      sizes: ["One Size"],
      materials: ["Genuine Leather"],
      tags: ["bag", "accessory", "leather"],
      rating: "4.9",
      reviewCount: 32,
      featured: true
    },
    {
      name: "Minimalist Watch",
      description: "Elegant minimalist watch with leather strap",
      price: "129.99",
      imageUrl: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&auto=format&fit=crop",
      inventory: 25,
      categoryId: createdCategories.find(c => c.slug === "accessories")?.id || 2,
      sku: "WT-MN-004",
      slug: "minimalist-watch",
      brand: "TimeStyle",
      colors: ["silver/brown", "gold/black"],
      sizes: ["One Size"],
      materials: ["Stainless Steel", "Leather"],
      tags: ["watch", "accessory", "timepiece"],
      rating: "4.7",
      reviewCount: 15,
      featured: false,
      isNew: true
    },
    {
      name: "Running Sneakers",
      description: "Lightweight and supportive sneakers for running and training",
      price: "79.99",
      imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop",
      inventory: 50,
      categoryId: createdCategories.find(c => c.slug === "footwear")?.id || 3,
      sku: "SH-RS-005",
      slug: "running-sneakers",
      brand: "ActiveStep",
      colors: ["black/white", "gray/blue", "red/black"],
      sizes: ["7", "8", "9", "10", "11", "12"],
      materials: ["Mesh", "Rubber"],
      tags: ["shoes", "running", "athletic"],
      rating: "4.6",
      reviewCount: 28,
      featured: true
    },
    {
      name: "Leather Loafers",
      description: "Classic leather loafers for a polished look",
      price: "99.99",
      imageUrl: "https://images.unsplash.com/photo-1614252235316-8c857d38b5f4?w=800&auto=format&fit=crop",
      inventory: 35,
      categoryId: createdCategories.find(c => c.slug === "footwear")?.id || 3,
      sku: "SH-LL-006",
      slug: "leather-loafers",
      brand: "ClassicStep",
      colors: ["brown", "black"],
      sizes: ["8", "9", "10", "11", "12"],
      materials: ["Genuine Leather"],
      tags: ["shoes", "formal", "loafers"],
      rating: "4.4",
      reviewCount: 12,
      featured: false
    },
    {
      name: "Decorative Throw Pillow",
      description: "Soft decorative throw pillows to accent your home",
      price: "29.99",
      imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&auto=format&fit=crop",
      inventory: 60,
      categoryId: createdCategories.find(c => c.slug === "home")?.id || 4,
      sku: "HM-TP-007",
      slug: "decorative-throw-pillow",
      brand: "HomeStyle",
      colors: ["navy", "gray", "cream", "teal"],
      sizes: ["18x18"],
      materials: ["Cotton", "Polyester"],
      tags: ["home", "decor", "pillow"],
      rating: "4.3",
      reviewCount: 9,
      featured: false,
      isNew: true
    },
    {
      name: "Scented Candle Set",
      description: "Set of 3 scented candles in decorative jars",
      price: "34.99",
      imageUrl: "https://images.unsplash.com/photo-1603006905393-c8eda4defb7f?w=800&auto=format&fit=crop",
      inventory: 40,
      categoryId: createdCategories.find(c => c.slug === "home")?.id || 4,
      sku: "HM-SC-008",
      slug: "scented-candle-set",
      brand: "AromaHome",
      colors: ["mixed"],
      sizes: ["One Size"],
      materials: ["Soy Wax", "Glass"],
      tags: ["home", "decor", "candles"],
      rating: "4.7",
      reviewCount: 14,
      featured: true
    }
  ];
  
  for (const product of products) {
    try {
      const allProducts = await storage.getProducts();
      const existingProduct = allProducts.find(p => p.slug === product.slug);
      
      if (!existingProduct) {
        const created = await storage.createProduct(product);
        console.log(`Created product: ${product.name}`);
      } else {
        console.log(`Product already exists: ${product.name}`);
      }
    } catch (error) {
      console.error(`Error creating product ${product.name}:`, error);
    }
  }
  
  console.log("Seeding completed!");
}

// Run the seeding function directly
seedInitialData()
  .then(() => console.log("Seeding completed successfully!"))
  .catch((error) => {
    console.error("Seeding failed:", error);
  });