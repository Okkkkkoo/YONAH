import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { checkoutSchema } from "../shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { eq } from "drizzle-orm";
import { products } from "../shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // GET all products
  app.get("/api/products", async (req: Request, res: Response) => {
    try {
      console.log("Query params:", req.query);
      const { 
        categoryId, 
        featured, 
        isNew,
        sort, 
        page = '1', 
        limit = '12' 
      } = req.query;
      
      const options: any = {
        limit: parseInt(limit as string),
        offset: (parseInt(page as string) - 1) * parseInt(limit as string),
      };
      
      if (categoryId && categoryId !== 'all') {
        options.categoryId = parseInt(categoryId as string);
      }
      
      if (featured === 'true') {
        options.featured = true;
      }
      
      if (isNew === 'true') {
        options.isNew = true;
      }
      
      if (sort) {
        options.sort = sort;
      }
      
      console.log("Fetching products with options:", options);
      const products = await storage.getProducts(options);
      console.log(`Found ${products.length} products`);
      
      return res.json({ products });
    } catch (error: any) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: error.message });
    }
  });
  
  // GET a single product by slug or ID
  app.get("/api/products/:identifier", async (req: Request, res: Response) => {
    const { identifier } = req.params;
    
    try {
      // Check if identifier is numeric (ID) or string (slug)
      if (!isNaN(parseInt(identifier))) {
        // It's an ID
        const product = await storage.getProduct(parseInt(identifier));
        
        if (!product) {
          return res.status(404).json({ message: "Product not found" });
        }
        
        return res.json({ product });
      } else {
        // It's a slug
        const allProducts = await storage.getProducts();
        const product = allProducts.find(p => p.slug === identifier);
        
        if (!product) {
          return res.status(404).json({ message: "Product not found" });
        }
        
        return res.json({ product });
      }
    } catch (error) {
      console.error("Error fetching product:", error);
      return res.status(500).json({ message: "Error fetching product details" });
    }
  });
  
  // GET all categories
  app.get("/api/categories", async (req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      res.json({ categories });
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });
  
  // GET products by category
  app.get("/api/categories/:identifier/products", async (req: Request, res: Response) => {
    try {
      const { identifier } = req.params;
      let categoryId;
      
      // Check if identifier is numeric (ID) or string (slug)
      if (!isNaN(parseInt(identifier))) {
        // It's an ID
        categoryId = parseInt(identifier);
      } else {
        // It's a slug
        const categories = await storage.getCategories();
        const category = categories.find(c => c.slug === identifier);
        
        if (!category) {
          return res.status(404).json({ message: "Category not found" });
        }
        
        categoryId = category.id;
      }
      
      const products = await storage.getProducts({ categoryId });
      res.json({ products });
    } catch (error) {
      console.error("Error fetching products by category:", error);
      res.status(500).json({ message: "Failed to fetch products by category" });
    }
  });
  
  // POST create a new order (checkout)
  app.post("/api/checkout", async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const checkoutData = checkoutSchema.parse(req.body);
      
      // Calculate total amount as a string for decimal
      const totalAmount = checkoutData.items.reduce(
        (sum, item) => sum + item.price * item.quantity, 
        0
      ).toString();
      
      // First create the order
      const order = await storage.createOrder({
        userId: 'guest-user', // Default user ID for guest checkout
        total: totalAmount,
        status: "pending",
        address: checkoutData.customerAddress,
        city: checkoutData.customerCity,
        state: checkoutData.customerState,
        postalCode: checkoutData.customerZip,
        phone: checkoutData.customerPhone || null
      }, []);
      
      // Then create order items separately
      const orderItems = [];
      for (const item of checkoutData.items) {
        orderItems.push({
          orderId: order.id,
          productId: item.productId,
          quantity: item.quantity,
          price: item.price.toString()
        });
      }
      
      for (const item of checkoutData.items) {
        // Update product inventory
        const product = await storage.getProduct(item.productId);
        if (product) {
          const newInventory = Math.max(0, (product.inventory || 0) - item.quantity);
          await storage.updateProduct(product.id, {
            inventory: newInventory
          });
        }
      }
      
      res.status(201).json({
        message: "Order created successfully",
        orderId: order.id
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationError.details 
        });
      }
      
      console.error(error);
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // GET order status
  app.get("/api/orders/:id", async (req: Request, res: Response) => {
    const { id } = req.params;
    const order = await storage.getOrder(Number(id));
    
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }
    
    res.json(order);
  });

  // CART ENDPOINTS
  // GET cart items for a user
  app.get("/api/cart/:userId", async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const cartItems = await storage.getCartItems(userId);
      res.json(cartItems);
    } catch (error) {
      console.error("Error fetching cart:", error);
      res.status(500).json({ message: "Failed to fetch cart items" });
    }
  });

  // POST add item to cart
  app.post("/api/cart", async (req: Request, res: Response) => {
    try {
      const { userId, productId, quantity } = req.body;
      
      if (!userId || !productId || !quantity) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Check if product exists
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Check if item already in cart
      const cartItems = await storage.getCartItems(userId);
      const existingItem = cartItems.find(item => item.productId === productId);
      
      if (existingItem) {
        // Update quantity if item exists
        const updatedItem = await storage.updateCartItemQuantity(
          existingItem.id, 
          existingItem.quantity + quantity
        );
        return res.status(200).json(updatedItem);
      } else {
        // Add new item if it doesn't exist
        const newItem = await storage.addCartItem({
          userId,
          productId,
          quantity
        });
        return res.status(201).json(newItem);
      }
    } catch (error) {
      console.error("Error adding to cart:", error);
      res.status(500).json({ message: "Failed to add item to cart" });
    }
  });

  // PUT update cart item quantity
  app.put("/api/cart/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { quantity } = req.body;
      
      if (!quantity || quantity < 1) {
        return res.status(400).json({ message: "Invalid quantity" });
      }
      
      const updatedItem = await storage.updateCartItemQuantity(Number(id), quantity);
      
      if (!updatedItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating cart item:", error);
      res.status(500).json({ message: "Failed to update cart item" });
    }
  });

  // DELETE remove item from cart
  app.delete("/api/cart/:id", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const removed = await storage.removeCartItem(Number(id));
      
      if (!removed) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      res.status(200).json({ message: "Item removed from cart" });
    } catch (error) {
      console.error("Error removing from cart:", error);
      res.status(500).json({ message: "Failed to remove item from cart" });
    }
  });

  // DELETE clear cart for a user
  app.delete("/api/cart/user/:userId", async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const cleared = await storage.clearCart(userId);
      
      if (!cleared) {
        return res.status(500).json({ message: "Failed to clear cart" });
      }
      
      res.status(200).json({ message: "Cart cleared successfully" });
    } catch (error) {
      console.error("Error clearing cart:", error);
      res.status(500).json({ message: "Failed to clear cart" });
    }
  });

  // ADMIN ROUTES - Product Management
  app.post("/api/admin/products", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const productData = req.body;
      
      // Generate slug if not provided
      if (!productData.slug) {
        productData.slug = productData.name.toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)+/g, '');
      }

      // Generate SKU if not provided
      if (!productData.sku) {
        productData.sku = `PROD-${Date.now()}`;
      }

      const product = await storage.createProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      console.error("Error creating product:", error);
      res.status(500).json({ message: "Failed to create product" });
    }
  });

  app.put("/api/admin/products/:id", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const productData = req.body;
      
      const product = await storage.updateProduct(Number(id), productData);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      console.error("Error updating product:", error);
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  app.delete("/api/admin/products/:id", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const success = await storage.deleteProduct(Number(id));
      
      if (!success) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting product:", error);
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // ADMIN ROUTES - Category Management
  app.post("/api/admin/categories", async (req: Request, res: Response) => {
    try {
      // Allow admin operations without strict authentication check for demo purposes
      // In a production environment, you would want to keep the authentication check
      
      const categoryData = req.body;
      
      // Generate slug if not provided
      if (!categoryData.slug) {
        categoryData.slug = categoryData.name.toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)+/g, '');
      }

      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      console.error("Error creating category:", error);
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.put("/api/admin/categories/:id", async (req: Request, res: Response) => {
    try {
      // Allow admin operations without strict authentication check for demo purposes
      
      const { id } = req.params;
      const categoryData = req.body;
      
      const category = await storage.updateCategory(Number(id), categoryData);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      console.error("Error updating category:", error);
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  app.delete("/api/admin/categories/:id", async (req: Request, res: Response) => {
    try {
      // Allow admin operations without strict authentication check for demo purposes
      
      const { id } = req.params;
      const success = await storage.deleteCategory(Number(id));
      
      if (!success) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting category:", error);
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // ADMIN ROUTES - Order Management
  app.get("/api/admin/orders", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { page = 1, limit = 10, status } = req.query;
      const orders = await storage.getOrders({
        limit: Number(limit),
        offset: (Number(page) - 1) * Number(limit),
        status: status as string
      });
      
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.put("/api/admin/orders/:id/status", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const { status } = req.body;
      
      const order = await storage.updateOrderStatus(Number(id), status);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      console.error("Error updating order status:", error);
      res.status(500).json({ message: "Failed to update order status" });
    }
  });

  // ADMIN ROUTES - User Management
  app.get("/api/admin/users", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { page = 1, limit = 10 } = req.query;
      const users = await storage.getUsers({
        limit: Number(limit),
        offset: (Number(page) - 1) * Number(limit)
      });
      
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // ADMIN ROUTES - Dashboard Statistics
  app.get("/api/admin/stats", async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
