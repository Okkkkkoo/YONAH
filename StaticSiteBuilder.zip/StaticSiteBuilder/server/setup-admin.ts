import { storage } from "./storage";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function setupAdmin() {
  console.log("Setting up admin user for StyleHub store...");
  
  // Admin credentials - you should change the password in production
  const adminCredentials = {
    username: "admin",
    password: "admin123",
    email: "admin@yona.com",
    firstName: "Yona",
    lastName: "Admin",
    role: "admin"
  };
  
  try {
    // Check if admin already exists
    const existingAdmin = await storage.getUserByUsername(adminCredentials.username);
    
    if (existingAdmin) {
      console.log("Admin user already exists with ID:", existingAdmin.id);
      
      // Ensure the role is set to admin
      if (existingAdmin.role !== "admin") {
        console.log("Updating user role to admin...");
        await storage.upsertUser({
          ...existingAdmin,
          role: "admin"
        });
        console.log("User role updated to admin successfully!");
      }
      
      console.log("Admin credentials:");
      console.log("Username:", adminCredentials.username);
      console.log("Password: [USE YOUR EXISTING PASSWORD]");
      return;
    }
    
    // Create a new admin user
    const hashedPassword = await hashPassword(adminCredentials.password);
    
    const newAdmin = await storage.createUser({
      ...adminCredentials,
      password: hashedPassword
    });
    
    console.log("Admin user created successfully with ID:", newAdmin.id);
    console.log("Admin credentials:");
    console.log("Username:", adminCredentials.username);
    console.log("Password:", adminCredentials.password);
    
  } catch (error) {
    console.error("Error setting up admin user:", error);
  }
}

// Run the function
setupAdmin()
  .then(() => {
    console.log("Admin setup complete!");
    process.exit(0);
  })
  .catch(error => {
    console.error("Admin setup failed:", error);
    process.exit(1);
  });