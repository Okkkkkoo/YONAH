
import { db } from './db';
import { users, categories, products } from '../shared/schema';
import { eq, sql } from 'drizzle-orm';

export async function seed() {
  console.log('Starting database seed...');
  
  try {
    // Check if admin user exists first
    const existingUsers = await db.select().from(users).where(eq(users.id, 'admin-user-1'));
    
    if (existingUsers.length === 0) {
      // Create admin user if doesn't exist
      await db.insert(users).values({
        id: 'admin-user-1',
        username: 'admin',
        password: 'temp_password',
        email: 'admin@example.com',
        firstName: 'Admin',
        lastName: 'User',
        role: 'admin'
      });
      console.log('Admin user created');
    } else {
      console.log('Admin user already exists');
    }

    // Check if categories exist
    const existingCategories = await db.select().from(categories).limit(1);
    
    if (existingCategories.length > 0) {
      console.log('Categories already exist, skipping category and product creation');
      return { success: true };
    }
    
    // Create categories
    const clothing = await db.insert(categories).values({
      name: 'Clothing',
      description: "Fashion clothing for all occasions",
      slug: 'clothing',
      featured: true,
      displayOrder: 1,
      image: 'https://images.unsplash.com/photo-1582142839970-2b9d5f8d6b88'
    }).returning();

    const electronics = await db.insert(categories).values({
      name: 'Electronics',
      description: "Latest gadgets and tech accessories",
      slug: 'electronics',
      featured: true,
      displayOrder: 2,
      image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661'
    }).returning();

    const homeDecor = await db.insert(categories).values({
      name: 'Home & Decor',
      description: "Furniture and home accessories",
      slug: 'home-decor',
      featured: true,
      displayOrder: 3,
      image: 'https://images.unsplash.com/photo-1493809842364-78817add7ffb'
    }).returning();
    console.log('Categories created');

    // Create women's subcategory
    const womensClothing = await db.insert(categories).values({
      name: "Women's Clothing",
      description: "Women's fashion clothing",
      slug: 'womens-clothing',
      parentId: clothing[0].id,
      displayOrder: 1,
      image: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5'
    }).returning();

    // Create men's subcategory
    const mensClothing = await db.insert(categories).values({
      name: "Men's Clothing",
      description: "Men's fashion clothing",
      slug: 'mens-clothing',
      parentId: clothing[0].id,
      displayOrder: 2,
      image: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8'
    }).returning();
    console.log('Subcategories created');

    // Create sample products
    await db.insert(products).values([
      {
        name: 'Floral Maxi Dress',
        description: 'Beautiful floral pattern maxi dress, perfect for summer occasions. Made from lightweight fabric with adjustable straps.',
        price: '99.99',
        imageUrl: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446',
        inventory: 10,
        categoryId: womensClothing[0].id,
        slug: 'floral-maxi-dress',
        featured: true,
        isNew: true,
        sku: 'WD-123',
        brand: 'Elegance',
        sizes: ['XS', 'S', 'M', 'L', 'XL'],
        colors: ['Blue', 'Red', 'White']
      },
      {
        name: 'Classic Slim Fit Shirt',
        description: 'Premium cotton slim fit shirt for men. Versatile design perfect for casual and formal settings.',
        price: '59.99',
        imageUrl: 'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99',
        inventory: 15,
        categoryId: mensClothing[0].id,
        slug: 'classic-shirt',
        sku: 'MS-456',
        brand: 'GentStyle',
        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
        colors: ['White', 'Light Blue', 'Black']
      },
      {
        name: 'Smartphone XZ Pro',
        description: 'Latest smartphone with 6.5" AMOLED display, 128GB storage and triple camera system.',
        price: '899.99',
        imageUrl: 'https://images.unsplash.com/photo-1598327105666-2c04ce9a520f',
        inventory: 8,
        categoryId: electronics[0].id,
        slug: 'smartphone-xz-pro',
        featured: true,
        sku: 'EL-789',
        brand: 'TechGiant',
        colors: ['Black', 'Silver', 'Gold']
      },
      {
        name: 'Modern Coffee Table',
        description: 'Stylish modern coffee table with minimalist design. Made from solid oak with tempered glass top.',
        price: '249.99',
        imageUrl: 'https://images.unsplash.com/photo-1530018607912-eff2daa1bac4',
        inventory: 5,
        categoryId: homeDecor[0].id,
        slug: 'modern-coffee-table',
        sku: 'HD-101',
        brand: 'HomeEssentials',
        materials: ['Wood', 'Glass']
      },
      {
        name: 'Wireless Earbuds',
        description: 'Premium wireless earbuds with active noise cancellation and 24-hour battery life.',
        price: '149.99',
        salePrice: '129.99',
        imageUrl: 'https://images.unsplash.com/photo-1606220838315-056192d5e927',
        inventory: 20,
        categoryId: electronics[0].id,
        slug: 'wireless-earbuds',
        isNew: true,
        onSale: true,
        sku: 'EL-222',
        brand: 'SoundMaster',
        colors: ['Black', 'White']
      },
      {
        name: 'Decorative Throw Pillows',
        description: 'Set of 2 decorative throw pillows with geometric patterns. Perfect accent for your sofa or bed.',
        price: '39.99',
        imageUrl: 'https://images.unsplash.com/photo-1579656381226-5fc0f0100c3b',
        inventory: 25,
        categoryId: homeDecor[0].id,
        slug: 'decorative-pillows',
        sku: 'HD-303',
        brand: 'ComfortLiving',
        colors: ['Blue/Gold', 'Gray/Silver', 'Green/Brown']
      }
    ]);
    console.log('Products created');

    console.log('Database seed completed successfully');
    return { success: true };
  } catch (error) {
    console.error('Error seeding database:', error);
    throw error;
  }
}

// Run the seed function
seed().catch(console.error);
