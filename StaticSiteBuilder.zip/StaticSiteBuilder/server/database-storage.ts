import { db } from "./db";
import { eq, and, or, desc, sql, gte, lte, like, SQL, isNull } from "drizzle-orm";
import { json } from "drizzle-orm/pg-core";
import crypto from "crypto";
import {
  users,
  categories,
  products,
  orders,
  orderItems,
  cartItems,
  type User,
  type Category,
  type Product,
  type Order,
  type OrderItem,
  type CartItem,
  type UpsertUser,
  type InsertUser,
  type InsertCategory,
  type InsertProduct,
  type InsertOrder,
  type InsertOrderItem,
  type InsertCartItem,
  type ProductWithCategory,
  type CartItemWithProduct,
  type OrderWithItems
} from "@shared/schema";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  
  async createUser(userData: any): Promise<User> {
    // Generate a UUID if no ID is provided
    if (!userData.id) {
      userData.id = crypto.randomUUID();
    }
    
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        updatedAt: new Date()
      })
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          address: userData.address,
          address2: userData.address2,
          city: userData.city,
          state: userData.state,
          postalCode: userData.postalCode,
          country: userData.country,
          phone: userData.phone,
          role: userData.role,
          preferredSizes: userData.preferredSizes,
          favoriteCategories: userData.favoriteCategories,
          newsletterSubscribed: userData.newsletterSubscribed,
          updatedAt: new Date()
        }
      })
      .returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db
      .select()
      .from(categories)
      .where(eq(categories.id, id));
    return category;
  }

  async getCategoryByName(name: string): Promise<Category | undefined> {
    const [category] = await db
      .select()
      .from(categories)
      .where(eq(categories.name, name));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db
      .insert(categories)
      .values(category)
      .returning();
    return newCategory;
  }

  async updateCategory(
    id: number,
    categoryData: Partial<InsertCategory>
  ): Promise<Category | undefined> {
    const [updatedCategory] = await db
      .update(categories)
      .set(categoryData)
      .where(eq(categories.id, id))
      .returning();
    return updatedCategory;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db
      .delete(categories)
      .where(eq(categories.id, id))
      .returning({ id: categories.id });
    return result.length > 0;
  }

  // Product operations
  async getProducts(options?: {
    limit?: number;
    offset?: number;
    categoryId?: number;
    featured?: boolean;
    isNew?: boolean;
    sort?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    minRating?: number;
    inStock?: boolean;
  }): Promise<ProductWithCategory[]> {
    console.log("Getting products with options:", options);
    
    // Use a simple query to get all products first
    let query = db.select().from(products);
    
    // Apply where conditions
    const whereConditions: SQL<unknown>[] = [];
    
    if (options?.categoryId) {
      whereConditions.push(eq(products.categoryId, options.categoryId));
    }
    
    if (options?.featured !== undefined) {
      whereConditions.push(eq(products.featured, options.featured));
    }
    
    if (options?.isNew !== undefined) {
      whereConditions.push(eq(products.isNew, options.isNew));
    }
    
    if (options?.search) {
      whereConditions.push(
        or(
          like(products.name, `%${options.search}%`),
          like(products.description || "", `%${options.search}%`),
          like(products.brand || "", `%${options.search}%`)
        )
      );
    }
    
    if (options?.minPrice !== undefined) {
      whereConditions.push(gte(products.price, options.minPrice.toString()));
    }
    
    if (options?.maxPrice !== undefined) {
      whereConditions.push(lte(products.price, options.maxPrice.toString()));
    }
    
    if (options?.minRating !== undefined) {
      whereConditions.push(gte(products.rating, options.minRating.toString()));
    }
    
    if (options?.inStock !== undefined && options.inStock) {
      whereConditions.push(gte(products.inventory, 1));
    }
    
    if (whereConditions.length > 0) {
      query = query.where(and(...whereConditions));
    }
    
    // Apply order by
    if (options?.sort === 'newest') {
      query = query.orderBy(desc(products.createdAt));
    } else if (options?.sort === 'price-low') {
      query = query.orderBy(products.price);
    } else if (options?.sort === 'price-high') {
      query = query.orderBy(desc(products.price));
    } else if (options?.sort === 'best-rated') {
      query = query.orderBy(desc(products.rating));
    } else {
      // Default sort by ID descending
      query = query.orderBy(desc(products.id));
    }
    
    // Apply limit and offset
    if (options?.limit !== undefined) {
      query = query.limit(options.limit);
    }
    
    if (options?.offset !== undefined) {
      query = query.offset(options.offset);
    }
    
    // Execute the query
    const productResults = await query;
    
    // Fetch categories for these products
    const productIds = productResults.map(p => p.id);
    
    if (productIds.length === 0) {
      console.log("No products found");
      return [];
    }
    
    // Get categories for these products
    const categoriesMap = new Map<number, Category>();
    const categoryResults = await db
      .select()
      .from(categories);
      
    categoryResults.forEach(category => {
      categoriesMap.set(category.id, category);
    });
    
    // Combine products with their categories
    const productsWithCategory = productResults.map(product => {
      const category = categoriesMap.get(product.categoryId);
      return {
        ...product,
        category: category || null
      };
    });
    
    console.log(`Found ${productsWithCategory.length} products`);
    return productsWithCategory as ProductWithCategory[];
  }

  async getProduct(id: number): Promise<ProductWithCategory | undefined> {
    const [result] = await db
      .select({
        product: products,
        category: categories
      })
      .from(products)
      .leftJoin(categories, eq(products.categoryId, categories.id))
      .where(eq(products.id, id));

    if (!result) return undefined;

    return {
      ...result.product,
      category: result.category
    } as ProductWithCategory;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db
      .insert(products)
      .values(product)
      .returning();
    return newProduct;
  }

  async updateProduct(
    id: number,
    productData: Partial<InsertProduct>
  ): Promise<Product | undefined> {
    const [updatedProduct] = await db
      .update(products)
      .set(productData)
      .where(eq(products.id, id))
      .returning();
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db
      .delete(products)
      .where(eq(products.id, id))
      .returning({ id: products.id });
    return result.length > 0;
  }

  async getProductCount(options?: {
    categoryId?: number;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    minRating?: number;
    inStock?: boolean;
  }): Promise<number> {
    let query = db.select({ count: sql<number>`count(*)` }).from(products);

    // Apply filters
    if (options) {
      const conditions: SQL<unknown>[] = [];

      if (options.categoryId) {
        conditions.push(eq(products.categoryId, options.categoryId));
      }

      if (options.search) {
        conditions.push(
          or(
            like(products.name, `%${options.search}%`),
            like(products.description || "", `%${options.search}%`),
            like(products.brand || "", `%${options.search}%`)
          )
        );
      }

      if (options.minPrice !== undefined) {
        conditions.push(gte(products.price, options.minPrice.toString()));
      }

      if (options.maxPrice !== undefined) {
        conditions.push(lte(products.price, options.maxPrice.toString()));
      }

      if (options.minRating !== undefined) {
        conditions.push(gte(products.rating, options.minRating.toString()));
      }

      if (options.inStock !== undefined && options.inStock) {
        conditions.push(gte(products.inventory, 1));
      }

      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }
    }

    const result = await query;
    return result[0].count;
  }

  // Order operations
  async getOrders(userId?: string): Promise<Order[]> {
    let query = db.select().from(orders);

    if (userId) {
      query = query.where(eq(orders.userId, userId));
    }

    query = query.orderBy(desc(orders.createdAt));
    return await query;
  }

  async getOrder(id: number): Promise<OrderWithItems | undefined> {
    const [order] = await db
      .select()
      .from(orders)
      .where(eq(orders.id, id));

    if (!order) return undefined;

    const items = await db
      .select({
        orderItem: orderItems,
        product: products
      })
      .from(orderItems)
      .innerJoin(products, eq(orderItems.productId, products.id))
      .where(eq(orderItems.orderId, id));

    const user = await this.getUser(order.userId);
    if (!user) return undefined;

    return {
      ...order,
      items: items.map(({ orderItem, product }) => ({
        ...orderItem,
        product
      })),
      user
    };
  }

  async createOrder(
    orderData: InsertOrder,
    items: InsertOrderItem[]
  ): Promise<Order> {
    // Start a transaction
    const result = await db.transaction(async (tx) => {
      // Insert the order
      const [order] = await tx.insert(orders).values(orderData).returning();

      // Insert all order items
      if (items.length > 0) {
        const orderItems = items.map((item) => ({
          ...item,
          orderId: order.id
        }));
        await tx.insert(orderItems).values(orderItems);
      }

      return order;
    });

    return result;
  }

  async updateOrderStatus(
    id: number,
    status: string
  ): Promise<Order | undefined> {
    const [updatedOrder] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
    return updatedOrder;
  }

  // Cart operations
  async getCartItems(userId: string): Promise<CartItemWithProduct[]> {
    const result = await db
      .select({
        cartItem: cartItems,
        product: products
      })
      .from(cartItems)
      .innerJoin(products, eq(cartItems.productId, products.id))
      .where(eq(cartItems.userId, userId));

    return result.map(({ cartItem, product }) => ({
      ...cartItem,
      product
    }));
  }

  async addCartItem(cartItem: InsertCartItem): Promise<CartItem> {
    // Check if the item is already in the cart
    const [existingItem] = await db
      .select()
      .from(cartItems)
      .where(
        and(
          eq(cartItems.userId, cartItem.userId),
          eq(cartItems.productId, cartItem.productId)
        )
      );

    if (existingItem) {
      // Update quantity
      const newQuantity = existingItem.quantity + cartItem.quantity;
      const [updated] = await db
        .update(cartItems)
        .set({ quantity: newQuantity })
        .where(eq(cartItems.id, existingItem.id))
        .returning();
      return updated;
    } else {
      // Insert new item
      const [newItem] = await db
        .insert(cartItems)
        .values(cartItem)
        .returning();
      return newItem;
    }
  }

  async updateCartItemQuantity(
    id: number,
    quantity: number
  ): Promise<CartItem | undefined> {
    const [updatedItem] = await db
      .update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    return updatedItem;
  }

  async removeCartItem(id: number): Promise<boolean> {
    const result = await db
      .delete(cartItems)
      .where(eq(cartItems.id, id))
      .returning({ id: cartItems.id });
    return result.length > 0;
  }

  async clearCart(userId: string): Promise<boolean> {
    const result = await db
      .delete(cartItems)
      .where(eq(cartItems.userId, userId))
      .returning({ id: cartItems.id });
    return true; // Even if no items were in the cart, consider it cleared
  }

  // Order management methods
  async getOrders(options?: {
    limit?: number;
    offset?: number;
    status?: string;
    userId?: string;
  }): Promise<OrderWithItems[]> {
    let query = db
      .select({
        order: orders,
        user: users,
        orderItem: orderItems,
        product: products
      })
      .from(orders)
      .leftJoin(users, eq(orders.userId, users.id))
      .leftJoin(orderItems, eq(orders.id, orderItems.orderId))
      .leftJoin(products, eq(orderItems.productId, products.id))
      .orderBy(desc(orders.createdAt));

    if (options) {
      const conditions: SQL[] = [];

      if (options.status) {
        conditions.push(eq(orders.status, options.status));
      }

      if (options.userId) {
        conditions.push(eq(orders.userId, options.userId));
      }

      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }

      if (options.limit) {
        query = query.limit(options.limit);
      }

      if (options.offset) {
        query = query.offset(options.offset);
      }
    }

    const results = await query;
    
    // Group by order ID
    const orderMap = new Map<number, OrderWithItems>();
    
    for (const result of results) {
      if (!result.order) continue;
      
      if (!orderMap.has(result.order.id)) {
        orderMap.set(result.order.id, {
          ...result.order,
          user: result.user!,
          items: []
        });
      }
      
      const order = orderMap.get(result.order.id)!;
      if (result.orderItem && result.product) {
        order.items.push({
          ...result.orderItem,
          product: result.product
        });
      }
    }
    
    return Array.from(orderMap.values());
  }

  // User management methods
  async getUsers(options?: {
    limit?: number;
    offset?: number;
  }): Promise<User[]> {
    let query = db.select().from(users);

    if (options) {
      if (options.limit) {
        query = query.limit(options.limit);
      }
      if (options.offset) {
        query = query.offset(options.offset);
      }
    }

    return await query;
  }

  // Admin statistics methods
  async getAdminStats(): Promise<{
    totalProducts: number;
    totalOrders: number;
    totalUsers: number;
    totalRevenue: number;
    recentOrders: OrderWithItems[];
    lowStockProducts: ProductWithCategory[];
  }> {
    // Get total counts
    const [productCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(products);

    const [orderCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(orders);

    const [userCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);

    // Get total revenue
    const [revenueResult] = await db
      .select({ total: sql<number>`sum(${orders.total}::numeric)` })
      .from(orders)
      .where(eq(orders.status, 'completed'));

    // Get recent orders
    const recentOrders = await this.getOrders({ limit: 5 });

    // Get low stock products
    const lowStockProducts = await this.getProducts({
      limit: 10,
      inStock: true
    });

    return {
      totalProducts: productCount.count,
      totalOrders: orderCount.count,
      totalUsers: userCount.count,
      totalRevenue: revenueResult.total || 0,
      recentOrders,
      lowStockProducts: lowStockProducts.filter(p => (p.inventory || 0) < 10)
    };
  }
}