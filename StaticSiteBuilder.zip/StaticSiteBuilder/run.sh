#!/bin/bash
echo "Starting Yona Women's Fashion E-commerce Platform..."
PORT=5001 NODE_ENV=development npx tsx server/index.ts